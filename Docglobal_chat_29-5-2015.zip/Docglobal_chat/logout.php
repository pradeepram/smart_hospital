<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		

$retrieve = mysql_query("select max(o_id) as oid from m_online where user_id='$userid'");
		
		while($rows = mysql_fetch_array($retrieve))
{
    $return3= "{$rows['oid']}" ;
    
 
  
    
}

 $add = mysql_query("update m_online set status=0,updatedTime=NOW() where user_id='$userid' and o_id='$return3'");




  echo json_encode(array("oid"=>$return3));
?>


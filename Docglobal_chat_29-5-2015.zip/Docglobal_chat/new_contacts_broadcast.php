<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
		$bid = (string) $_GET["bid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();

            


 $add = mysql_query("SELECT u.user_id,u.firstname as name,i.image,s.status_message FROM m_user u
left join m_image i on (i.user_id=u.user_id)
left join m_status s on (s.user_id=u.user_id)
where s.state=1 and u.user_id not in (select user_id from m_broadcast_members where b_id='$bid')");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['user_id']}" ;
     $return2= "{$row['name']}" ;      
      $return3= "{$row['image']}" ;      
	  $return4= "{$row['status_message']}" ;      
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
    $my_values2[] = $return3;    
$my_values3[] = $return4; 	
}




  echo json_encode(array("user_id"=>$my_values,"name"=>$my_values1,"image"=>$my_values2,"status"=>$my_values3));
?>


<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
	
	$userid = (string) $_GET["userid"];
     $rec_id = (string) $_GET["recipient_id"];    
			
		
$my_values = array();
$my_values1 = array();
 $my_values2 = array();               
	 $my_values3 = array(); 
	
		$result = mysql_query("SELECT u.firstname,c.message,
case when date_format(c.Time, '%Y-%m-%d') = date_format(curdate(), '%Y-%m-%d') then DATE_FORMAT(c.Time,'%H:%i')
else DATE_FORMAT(c.Time,'%Y-%m-%d %H:%i') end as Time,md5 FROM m_chat c 
left join m_user u on (u.user_id=c.user_id)
where c.user_id in ('$rec_id','$userid') and c.recipient in ('$rec_id','$userid')
order by c.Time asc");
while($rows = mysql_fetch_array($result))
{
    $return1= "{$rows['firstname']}" ;
     $return2= "{$rows['message']}" ;  
      $return3= "{$rows['Time']}" ;    
 $return4= "{$rows['md5']}" ;    	  
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
     $my_values2[] = $return3;                                                                     
	  $my_values3[] = $return4;    
}
		
	
	 echo json_encode(array("firstname"=>$my_values,"message"=>$my_values1,"md5"=>$my_values3,"time"=>$my_values2));
		
?>
<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();


 $add = mysql_query("select status,DATE_FORMAT(updatedTime,'%H:%i') as time from m_online where o_id=(select max(o_id) from m_online where user_id='$userid' )");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['status']}" ;
  $return2= "{$row['time']}" ;
  $my_values[] = $return1;  
   $my_values1[] = $return2;
   
}



  echo json_encode(array("status"=>$my_values,"time"=>$my_values1));
?>


<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
	$status = (string) $_GET["status"];    
	$userid = (string) $_GET["userid"];
    	
		
$my_values = array();
$my_values1 = array();
 $my_values2 = array();               
	
	
	$select = mysql_query("select state from m_status where user_id='$userid' and status_message='$status' and DATE(updatedTime)=DATE(NOW())"); 
		$output = mysql_num_rows(@$select);
		if ($output=="0")
		{	
	$update = mysql_query("update m_status set state=0 where user_id='$userid' and state=1");
		 $add = mysql_query("INSERT INTO m_status(status_message,user_id,state,updatedBy,updatedTime) VALUES('$status','$userid',1,'$userid',NOW())");
		}
		
		$result = mysql_query("select status_message,s_id from m_status where user_id='$userid'");
while($rows = mysql_fetch_array($result))
{
    $return1= "{$rows['status_message']}" ;
     $return2= "{$rows['s_id']}" ;  
          
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
                                                                       
}
		
	
	 echo json_encode(array("status_message"=>$my_values,"s_id"=>$my_values1));
		
?>
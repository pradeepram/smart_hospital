function g(a) {
    throw a;
}
var i = void 0,
    j = !0,
    m = null,
    n = !1;

function p() {
    return function() {}
}

function aa(a) {
    return function() {
        return this[a]
    }
}

function ba(a) {
    return function() {
        return a
    }
}
var q, s = this;

function ca(a, b) {
    var c = a.split("."),
        d = s;
    !(c[0] in d) && d.execScript && d.execScript("var " + c[0]);
    for (var f; c.length && (f = c.shift());) !c.length && da(b) ? d[f] = b : d = d[f] ? d[f] : d[f] = {}
}

function ea() {}

function fa(a) {
    a.qb = function() {
        return a.Cd ? a.Cd : a.Cd = new a
    }
}

function ga(a) {
    var b = typeof a;
    if ("object" == b)
        if (a) {
            if (a instanceof Array) return "array";
            if (a instanceof Object) return b;
            var c = Object.prototype.toString.call(a);
            if ("[object Window]" == c) return "object";
            if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) return "array";
            if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) return "function"
        } else return "null";
    else if ("function" == b && "undefined" == typeof a.call) return "object";
    return b
}

function da(a) {
    return a !== i
}

function ha(a) {
    return "array" == ga(a)
}

function ia(a) {
    var b = ga(a);
    return "array" == b || "object" == b && "number" == typeof a.length
}

function t(a) {
    return "string" == typeof a
}

function u(a) {
    return "function" == ga(a)
}

function ja(a) {
    var b = typeof a;
    return "object" == b && a != m || "function" == b
}

function ka(a) {
    return a[la] || (a[la] = ++ma)
}
var la = "closure_uid_" + Math.floor(2147483648 * Math.random()).toString(36),
    ma = 0;

function na(a, b, c) {
    return a.call.apply(a.bind, arguments)
}

function oa(a, b, c) {
    a || g(Error());
    if (2 < arguments.length) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function() {
            var c = Array.prototype.slice.call(arguments);
            Array.prototype.unshift.apply(c, d);
            return a.apply(b, c)
        }
    }
    return function() {
        return a.apply(b, arguments)
    }
}

function pa(a, b, c) {
    pa = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? na : oa;
    return pa.apply(m, arguments)
}

function qa(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function() {
        var b = Array.prototype.slice.call(arguments);
        b.unshift.apply(b, c);
        return a.apply(this, b)
    }
}
var ra = Date.now || function() {
    return +new Date
};

function v(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.H = b.prototype;
    a.prototype = new c;
    a.prototype.constructor = a
};

function sa(a) {
    return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "")
}

function ta(a) {
    if (!ua.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(va, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(wa, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(xa, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(ya, "&quot;"));
    return a
}
var va = /&/g,
    wa = /</g,
    xa = />/g,
    ya = /\"/g,
    ua = /[&<>\"]/;

function za(a) {
    return String(a).replace(/\-([a-z])/g, function(a, c) {
        return c.toUpperCase()
    })
};
var z = Array.prototype,
    Aa = z.indexOf ? function(a, b, c) {
        return z.indexOf.call(a, b, c)
    } : function(a, b, c) {
        c = c == m ? 0 : 0 > c ? Math.max(0, a.length + c) : c;
        if (t(a)) return !t(b) || 1 != b.length ? -1 : a.indexOf(b, c);
        for (; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    },
    B = z.forEach ? function(a, b, c) {
        z.forEach.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, f = t(a) ? a.split("") : a, e = 0; e < d; e++) e in f && b.call(c, f[e], e, a)
    },
    Ba = z.filter ? function(a, b, c) {
        return z.filter.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, f = [], e = 0, h = t(a) ? a.split("") :
                a, k = 0; k < d; k++)
            if (k in h) {
                var l = h[k];
                b.call(c, l, k, a) && (f[e++] = l)
            }
        return f
    },
    Ca = z.map ? function(a, b, c) {
        return z.map.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, f = Array(d), e = t(a) ? a.split("") : a, h = 0; h < d; h++) h in e && (f[h] = b.call(c, e[h], h, a));
        return f
    },
    Da = z.every ? function(a, b, c) {
        return z.every.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, f = t(a) ? a.split("") : a, e = 0; e < d; e++)
            if (e in f && !b.call(c, f[e], e, a)) return n;
        return j
    };

function Ea(a, b) {
    var c;
    a: {
        c = a.length;
        for (var d = t(a) ? a.split("") : a, f = 0; f < c; f++)
            if (f in d && b.call(i, d[f], f, a)) {
                c = f;
                break a
            }
        c = -1
    }
    return 0 > c ? m : t(a) ? a.charAt(c) : a[c]
}

function Fa(a, b) {
    return 0 <= Aa(a, b)
}

function C(a, b) {
    var c = Aa(a, b);
    0 <= c && z.splice.call(a, c, 1)
}

function Ga(a) {
    var b = a.length;
    if (0 < b) {
        for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
        return c
    }
    return []
}

function Ha(a, b) {
    for (var c = 1; c < arguments.length; c++) {
        var d = arguments[c],
            f;
        if (ha(d) || (f = ia(d)) && d.hasOwnProperty("callee")) a.push.apply(a, d);
        else if (f)
            for (var e = a.length, h = d.length, k = 0; k < h; k++) a[e + k] = d[k];
        else a.push(d)
    }
}

function Ia(a, b, c) {
    return 2 >= arguments.length ? z.slice.call(a, b) : z.slice.call(a, b, c)
}

function Ja(a, b) {
    return a > b ? 1 : a < b ? -1 : 0
};
var Ka, La, Ma, Na, Oa;

function Pa() {
    return s.navigator ? s.navigator.userAgent : m
}

function Qa() {
    return s.navigator
}
Na = Ma = La = Ka = n;
var Ra;
if (Ra = Pa()) {
    var Sa = Qa();
    Ka = 0 == Ra.indexOf("Opera");
    La = !Ka && -1 != Ra.indexOf("MSIE");
    Ma = !Ka && -1 != Ra.indexOf("WebKit");
    Na = !Ka && !Ma && "Gecko" == Sa.product
}
var Ta = Ka,
    D = La,
    E = Na,
    F = Ma,
    Ua = Qa();
Oa = -1 != (Ua && Ua.platform || "").indexOf("Mac");
var Va = !!Qa() && -1 != (Qa().appVersion || "").indexOf("X11"),
    Wa;
a: {
    var Xa = "",
        Ya;
    if (Ta && s.opera) var Za = s.opera.version,
        Xa = "function" == typeof Za ? Za() : Za;
    else if (E ? Ya = /rv\:([^\);]+)(\)|;)/ : D ? Ya = /MSIE\s+([^\);]+)(\)|;)/ : F && (Ya = /WebKit\/(\S+)/), Ya) var $a = Ya.exec(Pa()),
        Xa = $a ? $a[1] : "";
    if (D) {
        var ab, bb = s.document;
        ab = bb ? bb.documentMode : i;
        if (ab > parseFloat(Xa)) {
            Wa = String(ab);
            break a
        }
    }
    Wa = Xa
}
var cb = {};

function G(a) {
    var b;
    if (!(b = cb[a])) {
        b = 0;
        for (var c = sa(String(Wa)).split("."), d = sa(String(a)).split("."), f = Math.max(c.length, d.length), e = 0; 0 == b && e < f; e++) {
            var h = c[e] || "",
                k = d[e] || "",
                l = RegExp("(\\d*)(\\D*)", "g"),
                r = RegExp("(\\d*)(\\D*)", "g");
            do {
                var w = l.exec(h) || ["", "", ""],
                    y = r.exec(k) || ["", "", ""];
                if (0 == w[0].length && 0 == y[0].length) break;
                b = ((0 == w[1].length ? 0 : parseInt(w[1], 10)) < (0 == y[1].length ? 0 : parseInt(y[1], 10)) ? -1 : (0 == w[1].length ? 0 : parseInt(w[1], 10)) > (0 == y[1].length ? 0 : parseInt(y[1], 10)) ? 1 : 0) || ((0 == w[2].length) <
                    (0 == y[2].length) ? -1 : (0 == w[2].length) > (0 == y[2].length) ? 1 : 0) || (w[2] < y[2] ? -1 : w[2] > y[2] ? 1 : 0)
            } while (0 == b)
        }
        b = cb[a] = 0 <= b
    }
    return b
}
var db = {};

function eb(a) {
    return db[a] || (db[a] = D && !!document.documentMode && document.documentMode >= a)
};
var fb, gb = !D || eb(9);
!E && !D || D && eb(9) || E && G("1.9.1");
D && G("9");
var hb = D || Ta || F;

function ib(a) {
    a = a.className;
    return t(a) && a.match(/\S+/g) || []
}

function jb(a, b) {
    var c = ib(a),
        d = Ia(arguments, 1),
        f = c.length + d.length;
    kb(c, d);
    a.className = c.join(" ");
    return c.length == f
}

function lb(a, b) {
    var c = ib(a),
        d = Ia(arguments, 1),
        f = mb(c, d);
    a.className = f.join(" ");
    return f.length == c.length - d.length
}

function kb(a, b) {
    for (var c = 0; c < b.length; c++) Fa(a, b[c]) || a.push(b[c])
}

function mb(a, b) {
    return Ba(a, function(a) {
        return !Fa(b, a)
    })
}

function nb(a, b, c) {
    var d = ib(a);
    t(b) ? C(d, b) : ha(b) && (d = mb(d, b));
    t(c) && !Fa(d, c) ? d.push(c) : ha(c) && kb(d, c);
    a.className = d.join(" ")
};

function I(a, b) {
    this.x = da(a) ? a : 0;
    this.y = da(b) ? b : 0
};

function ob(a, b) {
    this.width = a;
    this.height = b
}
ob.prototype.floor = function() {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this
};
ob.prototype.round = function() {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this
};

function pb(a, b) {
    for (var c in a) b.call(i, a[c], c, a)
}
var qb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

function rb(a, b) {
    for (var c, d, f = 1; f < arguments.length; f++) {
        d = arguments[f];
        for (c in d) a[c] = d[c];
        for (var e = 0; e < qb.length; e++) c = qb[e], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
    }
};

function sb(a) {
    return a ? new tb(J(a)) : fb || (fb = new tb)
}

function ub(a, b) {
    pb(b, function(b, d) {
        "style" == d ? a.style.cssText = b : "class" == d ? a.className = b : "for" == d ? a.htmlFor = b : d in vb ? a.setAttribute(vb[d], b) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, b) : a[d] = b
    })
}
var vb = {
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    colspan: "colSpan",
    frameborder: "frameBorder",
    height: "height",
    maxlength: "maxLength",
    role: "role",
    rowspan: "rowSpan",
    type: "type",
    usemap: "useMap",
    valign: "vAlign",
    width: "width"
};

function wb(a, b, c) {
    var d = arguments,
        f = document,
        e = d[0],
        h = d[1];
    if (!gb && h && (h.name || h.type)) {
        e = ["<", e];
        h.name && e.push(' name="', ta(h.name), '"');
        if (h.type) {
            e.push(' type="', ta(h.type), '"');
            var k = {};
            rb(k, h);
            delete k.type;
            h = k
        }
        e.push(">");
        e = e.join("")
    }
    e = f.createElement(e);
    h && (t(h) ? e.className = h : ha(h) ? jb.apply(m, [e].concat(h)) : ub(e, h));
    2 < d.length && xb(f, e, d, 2);
    return e
}

function xb(a, b, c, d) {
    function f(c) {
        c && b.appendChild(t(c) ? a.createTextNode(c) : c)
    }
    for (; d < c.length; d++) {
        var e = c[d];
        if (ia(e) && !(ja(e) && 0 < e.nodeType)) {
            var h;
            a: {
                if (e && "number" == typeof e.length) {
                    if (ja(e)) {
                        h = "function" == typeof e.item || "string" == typeof e.item;
                        break a
                    }
                    if (u(e)) {
                        h = "function" == typeof e.item;
                        break a
                    }
                }
                h = n
            }
            B(h ? Ga(e) : e, f)
        } else f(e)
    }
}

function yb(a) {
    for (var b; b = a.firstChild;) a.removeChild(b)
}

function zb(a) {
    a && a.parentNode && a.parentNode.removeChild(a)
}

function Ab(a) {
    return ja(a) && 1 == a.nodeType
}

function Bb(a, b) {
    if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
    if ("undefined" != typeof a.compareDocumentPosition) return a == b || Boolean(a.compareDocumentPosition(b) & 16);
    for (; b && a != b;) b = b.parentNode;
    return b == a
}

function J(a) {
    return 9 == a.nodeType ? a : a.ownerDocument || a.document
}

function Cb(a) {
    var b = a.getAttributeNode("tabindex");
    return b && b.specified ? (a = a.tabIndex, "number" == typeof a && 0 <= a && 32768 > a) : n
}

function tb(a) {
    this.L = a || s.document || document
}
q = tb.prototype;
q.qd = sb;
q.d = function(a) {
    return t(a) ? this.L.getElementById(a) : a
};
q.ga = ub;
q.createElement = function(a) {
    return this.L.createElement(a)
};
q.createTextNode = function(a) {
    return this.L.createTextNode(a)
};

function Db(a) {
    var b = a.L,
        a = !F ? b.documentElement : b.body,
        b = b.parentWindow || b.defaultView;
    return new I(b.pageXOffset || a.scrollLeft, b.pageYOffset || a.scrollTop)
}
q.appendChild = function(a, b) {
    a.appendChild(b)
};
q.append = function(a, b) {
    xb(J(a), a, arguments, 1)
};
q.contains = Bb;
var Eb;
Eb = ba(j);
/*
 Portions of this code are from the Dojo Toolkit, received by
 The Closure Library Authors under the BSD license. All other code is
 Copyright 2005-2009 The Closure Library Authors. All Rights Reserved.

The "New" BSD License:

Copyright (c) 2005-2009, The Dojo Foundation
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this
    list of conditions and the following disclaimer.
 Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation
    and/or other materials provided with the distribution.
 Neither the name of the Dojo Foundation nor the names of its contributors
    may be used to endorse or promote products derived from this software
    without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
function Fb(a, b) {
    var c = b || [];
    a && c.push(a);
    return c
}
var Gb = F && "BackCompat" == document.compatMode,
    Hb = document.firstChild.children ? "children" : "childNodes",
    Ib = n;

function Jb(a) {
    function b() {
        0 <= r && (x.id = c(r, A).replace(/\\/g, ""), r = -1);
        if (0 <= w) {
            var a = w == A ? m : c(w, A);
            0 > ">~+".indexOf(a) ? x.D = a : x.Qb = a;
            w = -1
        }
        0 <= l && (x.ca.push(c(l + 1, A).replace(/\\/g, "")), l = -1)
    }

    function c(b, c) {
        return sa(a.slice(b, c))
    }
    for (var a = 0 <= ">~+".indexOf(a.slice(-1)) ? a + " * " : a + " ", d = [], f = -1, e = -1, h = -1, k = -1, l = -1, r = -1, w = -1, y = "", H = "", S, A = 0, Je = a.length, x = m, M = m; y = H, H = a.charAt(A), A < Je; A++)
        if ("\\" != y)
            if (x || (S = A, x = {
                    Va: m,
                    Aa: [],
                    Ab: [],
                    ca: [],
                    D: m,
                    Qb: m,
                    id: m,
                    rc: function() {
                        return Ib ? this.ie : this.D
                    }
                }, w = A), 0 <= f)
                if ("]" ==
                    H) {
                    M.nc ? M.yc = c(h || f + 1, A) : M.nc = c(f + 1, A);
                    if ((f = M.yc) && ('"' == f.charAt(0) || "'" == f.charAt(0))) M.yc = f.slice(1, -1);
                    x.Ab.push(M);
                    M = m;
                    f = h = -1
                } else "=" == H && (h = 0 <= "|~^$*".indexOf(y) ? y : "", M.type = h + H, M.nc = c(f + 1, A - h.length), h = A + 1);
    else 0 <= e ? ")" == H && (0 <= k && (M.value = c(e + 1, A)), k = e = -1) : "#" == H ? (b(), r = A + 1) : "." == H ? (b(), l = A) : ":" == H ? (b(), k = A) : "[" == H ? (b(), f = A, M = {}) : "(" == H ? (0 <= k && (M = {
        name: c(k + 1, A),
        value: m
    }, x.Aa.push(M)), e = A) : " " == H && y != H && (b(), 0 <= k && x.Aa.push({
            name: c(k + 1, A)
        }), x.Fd = x.Aa.length || x.Ab.length || x.ca.length, x.Be =
        x.Va = c(S, A), x.ie = x.D = x.Qb ? m : x.D || "*", x.D && (x.D = x.D.toUpperCase()), d.length && d[d.length - 1].Qb && (x.Bd = d.pop(), x.Va = x.Bd.Va + " " + x.Va), d.push(x), x = m);
    return d
}

function Kb(a, b) {
    return !a ? b : !b ? a : function() {
        return a.apply(window, arguments) && b.apply(window, arguments)
    }
}

function Lb(a) {
    return 1 == a.nodeType
}

function Mb(a, b) {
    return !a ? "" : "class" == b ? a.className || "" : "for" == b ? a.htmlFor || "" : "style" == b ? a.style.cssText || "" : (Ib ? a.getAttribute(b) : a.getAttribute(b, 2)) || ""
}
var Nb = {
        "*=": function(a, b) {
            return function(c) {
                return 0 <= Mb(c, a).indexOf(b)
            }
        },
        "^=": function(a, b) {
            return function(c) {
                return 0 == Mb(c, a).indexOf(b)
            }
        },
        "$=": function(a, b) {
            return function(c) {
                c = " " + Mb(c, a);
                return c.lastIndexOf(b) == c.length - b.length
            }
        },
        "~=": function(a, b) {
            var c = " " + b + " ";
            return function(b) {
                return 0 <= (" " + Mb(b, a) + " ").indexOf(c)
            }
        },
        "|=": function(a, b) {
            b = " " + b;
            return function(c) {
                c = " " + Mb(c, a);
                return c == b || 0 == c.indexOf(b + "-")
            }
        },
        "=": function(a, b) {
            return function(c) {
                return Mb(c, a) == b
            }
        }
    },
    Ob = "undefined" ==
    typeof document.firstChild.nextElementSibling,
    Pb = !Ob ? "nextElementSibling" : "nextSibling",
    Qb = !Ob ? "previousElementSibling" : "previousSibling",
    Rb = Ob ? Lb : Eb;

function Sb(a) {
    for (; a = a[Qb];)
        if (Rb(a)) return n;
    return j
}

function Tb(a) {
    for (; a = a[Pb];)
        if (Rb(a)) return n;
    return j
}

function Ub(a) {
    var b = a.parentNode,
        c = 0,
        d = b[Hb],
        f = a._i || -1,
        e = b._l || -1;
    if (!d) return -1;
    d = d.length;
    if (e == d && 0 <= f && 0 <= e) return f;
    b._l = d;
    f = -1;
    for (b = b.firstElementChild || b.firstChild; b; b = b[Pb]) Rb(b) && (b._i = ++c, a === b && (f = c));
    return f
}

function Vb(a) {
    return !(Ub(a) % 2)
}

function Wb(a) {
    return Ub(a) % 2
}
var Yb = {
        checked: function() {
            return function(a) {
                return a.checked || a.attributes.checked
            }
        },
        "first-child": function() {
            return Sb
        },
        "last-child": function() {
            return Tb
        },
        "only-child": function() {
            return function(a) {
                return !Sb(a) || !Tb(a) ? n : j
            }
        },
        empty: function() {
            return function(a) {
                for (var b = a.childNodes, a = a.childNodes.length - 1; 0 <= a; a--) {
                    var c = b[a].nodeType;
                    if (1 === c || 3 == c) return n
                }
                return j
            }
        },
        contains: function(a, b) {
            var c = b.charAt(0);
            if ('"' == c || "'" == c) b = b.slice(1, -1);
            return function(a) {
                return 0 <= a.innerHTML.indexOf(b)
            }
        },
        not: function(a, b) {
            var c = Jb(b)[0],
                d = {
                    z: 1
                };
            "*" != c.D && (d.D = 1);
            c.ca.length || (d.ca = 1);
            var f = Xb(c, d);
            return function(a) {
                return !f(a)
            }
        },
        "nth-child": function(a, b) {
            if ("odd" == b) return Wb;
            if ("even" == b) return Vb;
            if (-1 != b.indexOf("n")) {
                var c = b.split("n", 2),
                    d = c[0] ? "-" == c[0] ? -1 : parseInt(c[0], 10) : 1,
                    f = c[1] ? parseInt(c[1], 10) : 0,
                    e = 0,
                    h = -1;
                0 < d ? 0 > f ? f = f % d && d + f % d : 0 < f && (f >= d && (e = f - f % d), f %= d) : 0 > d && (d *= -1, 0 < f && (h = f, f %= d));
                if (0 < d) return function(a) {
                    a = Ub(a);
                    return a >= e && (0 > h || a <= h) && a % d == f
                };
                b = f
            }
            var k = parseInt(b, 10);
            return function(a) {
                return Ub(a) ==
                    k
            }
        }
    },
    Zb = D ? function(a) {
        var b = a.toLowerCase();
        "class" == b && (a = "className");
        return function(c) {
            return Ib ? c.getAttribute(a) : c[a] || c[b]
        }
    } : function(a) {
        return function(b) {
            return b && b.getAttribute && b.hasAttribute(a)
        }
    };

function Xb(a, b) {
    if (!a) return Eb;
    var b = b || {},
        c = m;
    b.z || (c = Kb(c, Lb));
    b.D || "*" != a.D && (c = Kb(c, function(b) {
        return b && b.tagName == a.rc()
    }));
    b.ca || B(a.ca, function(a, b) {
        var e = RegExp("(?:^|\\s)" + a + "(?:\\s|$)");
        c = Kb(c, function(a) {
            return e.test(a.className)
        });
        c.count = b
    });
    b.Aa || B(a.Aa, function(a) {
        var b = a.name;
        Yb[b] && (c = Kb(c, Yb[b](b, a.value)))
    });
    b.Ab || B(a.Ab, function(a) {
        var b, e = a.nc;
        a.type && Nb[a.type] ? b = Nb[a.type](e, a.yc) : e.length && (b = Zb(e));
        b && (c = Kb(c, b))
    });
    b.id || a.id && (c = Kb(c, function(b) {
        return !!b && b.id == a.id
    }));
    c || "default" in b || (c = Eb);
    return c
}
var $b = {};

function ac(a) {
    var b = $b[a.Va];
    if (b) return b;
    var c = a.Bd,
        c = c ? c.Qb : "",
        d = Xb(a, {
            z: 1
        }),
        f = "*" == a.D,
        e = document.getElementsByClassName;
    if (c)
        if (e = {
                z: 1
            }, f && (e.D = 1), d = Xb(a, e), "+" == c) var h = d,
            b = function(a, b, c) {
                for (; a = a[Pb];)
                    if (!Ob || Lb(a)) {
                        (!c || bc(a, c)) && h(a) && b.push(a);
                        break
                    }
                return b
            };
        else if ("~" == c) var k = d,
        b = function(a, b, c) {
            for (a = a[Pb]; a;) {
                if (Rb(a)) {
                    if (c && !bc(a, c)) break;
                    k(a) && b.push(a)
                }
                a = a[Pb]
            }
            return b
        };
    else {
        if (">" == c) var l = d,
            l = l || Eb,
            b = function(a, b, c) {
                for (var d = 0, f = a[Hb]; a = f[d++];) Rb(a) && ((!c || bc(a, c)) && l(a, d)) &&
                    b.push(a);
                return b
            }
    } else if (a.id) d = !a.Fd && f ? Eb : Xb(a, {
        z: 1,
        id: 1
    }), b = function(b, c) {
        var f = sb(b).d(a.id),
            e;
        if (e = f && d(f))
            if (!(e = 9 == b.nodeType)) {
                for (e = f.parentNode; e && e != b;) e = e.parentNode;
                e = !!e
            }
        if (e) return Fb(f, c)
    };
    else if (e && /\{\s*\[native code\]\s*\}/.test(String(e)) && a.ca.length && !Gb) var d = Xb(a, {
            z: 1,
            ca: 1,
            id: 1
        }),
        r = a.ca.join(" "),
        b = function(a, b) {
            for (var c = Fb(0, b), f, e = 0, h = a.getElementsByClassName(r); f = h[e++];) d(f, a) && c.push(f);
            return c
        };
    else !f && !a.Fd ? b = function(b, c) {
        for (var d = Fb(0, c), f, e = 0, h = b.getElementsByTagName(a.rc()); f =
            h[e++];) d.push(f);
        return d
    } : (d = Xb(a, {
        z: 1,
        D: 1,
        id: 1
    }), b = function(b, c) {
        for (var f = Fb(0, c), e, h = 0, k = b.getElementsByTagName(a.rc()); e = k[h++];) d(e, b) && f.push(e);
        return f
    });
    return $b[a.Va] = b
}
var cc = {},
    dc = {};

function ec(a) {
    var b = Jb(sa(a));
    if (1 == b.length) {
        var c = ac(b[0]);
        return function(a) {
            if (a = c(a, [])) a.Pb = j;
            return a
        }
    }
    return function(a) {
        for (var a = Fb(a), c, e, h = b.length, k, l, r = 0; r < h; r++) {
            l = [];
            c = b[r];
            e = a.length - 1;
            0 < e && (k = {}, l.Pb = j);
            e = ac(c);
            for (var w = 0; c = a[w]; w++) e(c, l, k);
            if (!l.length) break;
            a = l
        }
        return l
    }
}
var fc = !!document.querySelectorAll && (!F || G("526"));

function gc(a, b) {
    if (fc) {
        var c = dc[a];
        if (c && !b) return c
    }
    if (c = cc[a]) return c;
    var c = a.charAt(0),
        d = -1 == a.indexOf(" ");
    0 <= a.indexOf("#") && d && (b = j);
    if (fc && !b && -1 == ">~+".indexOf(c) && (!D || -1 == a.indexOf(":")) && !(Gb && 0 <= a.indexOf(".")) && -1 == a.indexOf(":contains") && -1 == a.indexOf("|=")) {
        var f = 0 <= ">~+".indexOf(a.charAt(a.length - 1)) ? a + " *" : a;
        return dc[a] = function(b) {
            try {
                9 == b.nodeType || d || g("");
                var c = b.querySelectorAll(f);
                D ? c.Ud = j : c.Pb = j;
                return c
            } catch (e) {
                return gc(a, j)(b)
            }
        }
    }
    var e = a.split(/\s*,\s*/);
    return cc[a] =
        2 > e.length ? ec(a) : function(a) {
            for (var b = 0, c = [], d; d = e[b++];) c = c.concat(ec(d)(a));
            return c
        }
}
var hc = 0,
    ic = D ? function(a) {
        return Ib ? a.getAttribute("_uid") || a.setAttribute("_uid", ++hc) || hc : a.uniqueID
    } : function(a) {
        return a._uid || (a._uid = ++hc)
    };

function bc(a, b) {
    if (!b) return 1;
    var c = ic(a);
    return !b[c] ? b[c] = 1 : 0
}

function jc(a) {
    if (a && a.Pb) return a;
    var b = [];
    if (!a || !a.length) return b;
    a[0] && b.push(a[0]);
    if (2 > a.length) return b;
    hc++;
    if (D && Ib) {
        var c = hc + "";
        a[0].setAttribute("_zipIdx", c);
        for (var d = 1, f; f = a[d]; d++) a[d].getAttribute("_zipIdx") != c && b.push(f), f.setAttribute("_zipIdx", c)
    } else if (D && a.Ud) try {
        for (d = 1; f = a[d]; d++) Lb(f) && b.push(f)
    } catch (e) {} else {
        a[0] && (a[0]._zipIdx = hc);
        for (d = 1; f = a[d]; d++) a[d]._zipIdx != hc && b.push(f), f._zipIdx = hc
    }
    return b
}

function K(a, b) {
    if (!a) return [];
    if (a.constructor == Array) return a;
    if (!t(a)) return [a];
    if (t(b) && (b = t(b) ? document.getElementById(b) : b, !b)) return [];
    var b = b || document,
        c = b.ownerDocument || b.documentElement;
    Ib = b.contentType && "application/xml" == b.contentType || Ta && (b.doctype || "[object XMLDocument]" == c.toString()) || !!c && (D ? c.xml : b.xmlVersion || c.xmlVersion);
    return (c = gc(a)(b)) && c.Pb ? c : jc(c)
}
K.Aa = Yb;
ca("goog.dom.query", K);
ca("goog.dom.query.pseudos", K.Aa);
var kc = !D || eb(9),
    lc = !D || eb(9),
    mc = D && !G("9");
!F || G("528");
E && G("1.9b") || D && G("8") || Ta && G("9.5") || F && G("528");
E && !G("8") || D && G("9");

function nc() {
    0 != oc && (this.te = Error().stack, ka(this))
}
var oc = 0;
nc.prototype.md = n;

function pc(a, b) {
    this.type = a;
    this.currentTarget = this.target = b
}
q = pc.prototype;
q.za = n;
q.defaultPrevented = n;
q.Tb = j;
q.stopPropagation = function() {
    this.za = j
};
q.preventDefault = function() {
    this.defaultPrevented = j;
    this.Tb = n
};

function qc(a) {
    a.preventDefault()
};

function rc(a) {
    rc[" "](a);
    return a
}
rc[" "] = ea;

function sc(a, b) {
    a && this.init(a, b)
}
v(sc, pc);
var tc = [1, 4, 2];
q = sc.prototype;
q.target = m;
q.relatedTarget = m;
q.offsetX = 0;
q.offsetY = 0;
q.clientX = 0;
q.clientY = 0;
q.screenX = 0;
q.screenY = 0;
q.button = 0;
q.keyCode = 0;
q.charCode = 0;
q.ctrlKey = n;
q.altKey = n;
q.shiftKey = n;
q.metaKey = n;
q.Dc = n;
q.n = m;
q.init = function(a, b) {
    var c = this.type = a.type;
    pc.call(this, c);
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    var d = a.relatedTarget;
    if (d) {
        if (E) {
            var f;
            a: {
                try {
                    rc(d.nodeName);
                    f = j;
                    break a
                } catch (e) {}
                f = n
            }
            f || (d = m)
        }
    } else "mouseover" == c ? d = a.fromElement : "mouseout" == c && (d = a.toElement);
    this.relatedTarget = d;
    this.offsetX = F || a.offsetX !== i ? a.offsetX : a.layerX;
    this.offsetY = F || a.offsetY !== i ? a.offsetY : a.layerY;
    this.clientX = a.clientX !== i ? a.clientX : a.pageX;
    this.clientY = a.clientY !== i ? a.clientY : a.pageY;
    this.screenX =
        a.screenX || 0;
    this.screenY = a.screenY || 0;
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.Dc = Oa ? a.metaKey : a.ctrlKey;
    this.state = a.state;
    this.n = a;
    a.defaultPrevented && this.preventDefault();
    delete this.za
};

function uc(a) {
    return (kc ? 0 == a.n.button : "click" == a.type ? j : !!(a.n.button & tc[0])) && !(F && Oa && a.ctrlKey)
}
q.stopPropagation = function() {
    sc.H.stopPropagation.call(this);
    this.n.stopPropagation ? this.n.stopPropagation() : this.n.cancelBubble = j
};
q.preventDefault = function() {
    sc.H.preventDefault.call(this);
    var a = this.n;
    if (a.preventDefault) a.preventDefault();
    else if (a.returnValue = n, mc) try {
        if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
    } catch (b) {}
};
q.Vd = aa("n");

function vc() {}
var wc = 0;
q = vc.prototype;
q.key = 0;
q.Ba = n;
q.gd = n;
q.init = function(a, b, c, d, f, e) {
    u(a) ? this.Ed = j : a && a.handleEvent && u(a.handleEvent) ? this.Ed = n : g(Error("Invalid listener argument"));
    this.Ua = a;
    this.Id = b;
    this.src = c;
    this.type = d;
    this.capture = !!f;
    this.Qa = e;
    this.gd = n;
    this.key = ++wc;
    this.Ba = n
};
q.handleEvent = function(a) {
    return this.Ed ? this.Ua.call(this.Qa || this.src, a) : this.Ua.handleEvent.call(this.Ua, a)
};
var xc = {},
    L = {},
    yc = {},
    zc = {};

function N(a, b, c, d, f) {
    if (b) {
        if (ha(b)) {
            for (var e = 0; e < b.length; e++) N(a, b[e], c, d, f);
            return m
        }
        var d = !!d,
            h = L;
        b in h || (h[b] = {
            m: 0,
            N: 0
        });
        h = h[b];
        d in h || (h[d] = {
            m: 0,
            N: 0
        }, h.m++);
        var h = h[d],
            k = ka(a),
            l;
        h.N++;
        if (h[k]) {
            l = h[k];
            for (e = 0; e < l.length; e++)
                if (h = l[e], h.Ua == c && h.Qa == f) {
                    if (h.Ba) break;
                    return l[e].key
                }
        } else l = h[k] = [], h.m++;
        var r = Ac,
            w = lc ? function(a) {
                return r.call(w.src, w.key, a)
            } : function(a) {
                a = r.call(w.src, w.key, a);
                if (!a) return a
            },
            e = w;
        e.src = a;
        h = new vc;
        h.init(c, e, a, b, d, f);
        c = h.key;
        e.key = c;
        l.push(h);
        xc[c] = h;
        yc[k] ||
            (yc[k] = []);
        yc[k].push(h);
        a.addEventListener ? (a == s || !a.jd) && a.addEventListener(b, e, d) : a.attachEvent(b in zc ? zc[b] : zc[b] = "on" + b, e);
        return c
    }
    g(Error("Invalid event type"))
}

function Bc(a, b, c, d, f) {
    if (ha(b))
        for (var e = 0; e < b.length; e++) Bc(a, b[e], c, d, f);
    else if (d = !!d, a = Cc(a, b, d))
        for (e = 0; e < a.length; e++)
            if (a[e].Ua == c && a[e].capture == d && a[e].Qa == f) {
                O(a[e].key);
                break
            }
}

function O(a) {
    if (!xc[a]) return n;
    var b = xc[a];
    if (b.Ba) return n;
    var c = b.src,
        d = b.type,
        f = b.Id,
        e = b.capture;
    c.removeEventListener ? (c == s || !c.jd) && c.removeEventListener(d, f, e) : c.detachEvent && c.detachEvent(d in zc ? zc[d] : zc[d] = "on" + d, f);
    c = ka(c);
    yc[c] && (f = yc[c], C(f, b), 0 == f.length && delete yc[c]);
    b.Ba = j;
    if (b = L[d][e][c]) b.Hd = j, Dc(d, e, c, b);
    delete xc[a];
    return j
}

function Dc(a, b, c, d) {
    if (!d.Kb && d.Hd) {
        for (var f = 0, e = 0; f < d.length; f++) d[f].Ba ? d[f].Id.src = m : (f != e && (d[e] = d[f]), e++);
        d.length = e;
        d.Hd = n;
        0 == e && (delete L[a][b][c], L[a][b].m--, 0 == L[a][b].m && (delete L[a][b], L[a].m--), 0 == L[a].m && delete L[a])
    }
}

function Cc(a, b, c) {
    var d = L;
    return b in d && (d = d[b], c in d && (d = d[c], a = ka(a), d[a])) ? d[a] : m
}

function Ec(a, b, c, d, f) {
    var e = 1,
        b = ka(b);
    if (a[b]) {
        a.N--;
        a = a[b];
        a.Kb ? a.Kb++ : a.Kb = 1;
        try {
            for (var h = a.length, k = 0; k < h; k++) {
                var l = a[k];
                l && !l.Ba && (e &= Fc(l, f) !== n)
            }
        } finally {
            a.Kb--, Dc(c, d, b, a)
        }
    }
    return Boolean(e)
}

function Fc(a, b) {
    a.gd && O(a.key);
    return a.handleEvent(b)
}

function Ac(a, b) {
    if (!xc[a]) return j;
    var c = xc[a],
        d = c.type,
        f = L;
    if (!(d in f)) return j;
    var f = f[d],
        e, h;
    if (!lc) {
        var k;
        if (!(k = b)) a: {
            k = ["window", "event"];
            for (var l = s; e = k.shift();)
                if (l[e] != m) l = l[e];
                else {
                    k = m;
                    break a
                }
            k = l
        }
        e = k;
        k = j in f;
        l = n in f;
        if (k) {
            if (0 > e.keyCode || e.returnValue != i) return j;
            a: {
                var r = n;
                if (0 == e.keyCode) try {
                    e.keyCode = -1;
                    break a
                } catch (w) {
                    r = j
                }
                if (r || e.returnValue == i) e.returnValue = j
            }
        }
        r = new sc;
        r.init(e, this);
        e = j;
        try {
            if (k) {
                for (var y = [], H = r.currentTarget; H; H = H.parentNode) y.push(H);
                h = f[j];
                h.N = h.m;
                for (var S =
                        y.length - 1; !r.za && 0 <= S && h.N; S--) r.currentTarget = y[S], e &= Ec(h, y[S], d, j, r);
                if (l) {
                    h = f[n];
                    h.N = h.m;
                    for (S = 0; !r.za && S < y.length && h.N; S++) r.currentTarget = y[S], e &= Ec(h, y[S], d, n, r)
                }
            } else e = Fc(c, r)
        } finally {
            y && (y.length = 0)
        }
        return e
    }
    d = new sc(b, this);
    return e = Fc(c, d)
};

function Gc(a) {
    nc.call(this);
    this.yd = a;
    this.h = []
}
v(Gc, nc);
var Hc = [];

function P(a, b, c, d, f) {
    ha(c) || (Hc[0] = c, c = Hc);
    for (var e = 0; e < c.length; e++) {
        var h = N(b, c[e], d || a, f || n, a.yd || a);
        a.h.push(h)
    }
    return a
}

function Ic(a, b, c, d, f, e) {
    if (ha(c))
        for (var h = 0; h < c.length; h++) Ic(a, b, c[h], d, f, e);
    else {
        a: {
            d = d || a;
            e = e || a.yd || a;
            f = !!f;
            if (b = Cc(b, c, f))
                for (c = 0; c < b.length; c++)
                    if (!b[c].Ba && b[c].Ua == d && b[c].capture == f && b[c].Qa == e) {
                        b = b[c];
                        break a
                    }
            b = m
        }
        b && (b = b.key, O(b), C(a.h, b))
    }
    return a
}
Gc.prototype.Rb = function() {
    B(this.h, O);
    this.h.length = 0
};
Gc.prototype.handleEvent = function() {
    g(Error("EventHandler.handleEvent not implemented"))
};

function Jc() {
    nc.call(this)
}
v(Jc, nc);
q = Jc.prototype;
q.jd = j;
q.Cc = m;
q.Hc = function(a) {
    this.Cc = a
};
q.addEventListener = function(a, b, c, d) {
    N(this, a, b, c, d)
};
q.removeEventListener = function(a, b, c, d) {
    Bc(this, a, b, c, d)
};
q.dispatchEvent = function(a) {
    var b = a.type || a,
        c = L;
    if (b in c) {
        if (t(a)) a = new pc(a, this);
        else if (a instanceof pc) a.target = a.target || this;
        else {
            var d = a,
                a = new pc(b, this);
            rb(a, d)
        }
        var d = 1,
            f, c = c[b],
            b = j in c,
            e;
        if (b) {
            f = [];
            for (e = this; e; e = e.Cc) f.push(e);
            e = c[j];
            e.N = e.m;
            for (var h = f.length - 1; !a.za && 0 <= h && e.N; h--) a.currentTarget = f[h], d &= Ec(e, f[h], a.type, j, a) && a.Tb != n
        }
        if (n in c)
            if (e = c[n], e.N = e.m, b)
                for (h = 0; !a.za && h < f.length && e.N; h++) a.currentTarget = f[h], d &= Ec(e, f[h], a.type, n, a) && a.Tb != n;
            else
                for (f = this; !a.za && f && e.N; f =
                    f.Cc) a.currentTarget = f, d &= Ec(e, f, a.type, n, a) && a.Tb != n;
        a = Boolean(d)
    } else a = j;
    return a
};

function Kc(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d
}
Kc.prototype.contains = function(a) {
    return !this || !a ? n : a instanceof Kc ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.y >= this.top && a.y <= this.bottom
};

function Lc(a, b, c, d) {
    this.left = a;
    this.top = b;
    this.width = c;
    this.height = d
}
Lc.prototype.contains = function(a) {
    return a instanceof Lc ? this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height : a.x >= this.left && a.x <= this.left + this.width && a.y >= this.top && a.y <= this.top + this.height
};

function Q(a, b, c) {
    t(b) ? Mc(a, c, b) : pb(b, qa(Mc, a))
}

function Mc(a, b, c) {
    a.style[za(c)] = b
}

function R(a, b) {
    var c = J(a);
    return c.defaultView && c.defaultView.getComputedStyle && (c = c.defaultView.getComputedStyle(a, m)) ? c[b] || c.getPropertyValue(b) || "" : ""
}

function Nc(a, b) {
    return a.currentStyle ? a.currentStyle[b] : m
}

function Oc(a, b) {
    return R(a, b) || Nc(a, b) || a.style && a.style[b]
}

function Pc(a, b, c) {
    var d, f = E && (Oa || Va) && G("1.9");
    b instanceof I ? (d = b.x, b = b.y) : (d = b, b = c);
    a.style.left = Qc(d, f);
    a.style.top = Qc(b, f)
}

function Rc(a) {
    var b = a.getBoundingClientRect();
    D && (a = a.ownerDocument, b.left -= a.documentElement.clientLeft + a.body.clientLeft, b.top -= a.documentElement.clientTop + a.body.clientTop);
    return b
}

function Sc(a) {
    if (D && !eb(8)) return a.offsetParent;
    for (var b = J(a), c = Oc(a, "position"), d = "fixed" == c || "absolute" == c, a = a.parentNode; a && a != b; a = a.parentNode)
        if (c = Oc(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" == c || "relative" == c)) return a;
    return m
}

function Tc(a) {
    var b, c = J(a),
        d = Oc(a, "position"),
        f = E && c.getBoxObjectFor && !a.getBoundingClientRect && "absolute" == d && (b = c.getBoxObjectFor(a)) && (0 > b.screenX || 0 > b.screenY),
        e = new I(0, 0),
        h;
    b = c ? J(c) : document;
    if (h = D)
        if (h = !eb(9)) sb(b), h = n;
    h = h ? b.body : b.documentElement;
    if (a == h) return e;
    if (a.getBoundingClientRect) b = Rc(a), a = Db(sb(c)), e.x = b.left + a.x, e.y = b.top + a.y;
    else if (c.getBoxObjectFor && !f) b = c.getBoxObjectFor(a), a = c.getBoxObjectFor(h), e.x = b.screenX - a.screenX, e.y = b.screenY - a.screenY;
    else {
        f = a;
        do {
            e.x += f.offsetLeft;
            e.y += f.offsetTop;
            f != a && (e.x += f.clientLeft || 0, e.y += f.clientTop || 0);
            if (F && "fixed" == Oc(f, "position")) {
                e.x += c.body.scrollLeft;
                e.y += c.body.scrollTop;
                break
            }
            f = f.offsetParent
        } while (f && f != a);
        if (Ta || F && "absolute" == d) e.y -= c.body.offsetTop;
        for (f = a;
            (f = Sc(f)) && f != c.body && f != h;)
            if (e.x -= f.scrollLeft, !Ta || "TR" != f.tagName) e.y -= f.scrollTop
    }
    return e
}

function Uc(a, b) {
    var c = Vc(a),
        d = Vc(b);
    return new I(c.x - d.x, c.y - d.y)
}

function Vc(a) {
    var b = new I;
    if (1 == a.nodeType) {
        if (a.getBoundingClientRect) {
            var c = Rc(a);
            b.x = c.left;
            b.y = c.top
        } else {
            var c = Db(sb(a)),
                d = Tc(a);
            b.x = d.x - c.x;
            b.y = d.y - c.y
        }
        if (E && !G(12)) {
            var f;
            D ? f = "-ms-transform" : F ? f = "-webkit-transform" : Ta ? f = "-o-transform" : E && (f = "-moz-transform");
            var e;
            f && (e = Oc(a, f));
            e || (e = Oc(a, "transform"));
            e ? (a = e.match(Wc), a = !a ? new I(0, 0) : new I(parseFloat(a[1]), parseFloat(a[2]))) : a = new I(0, 0);
            b = new I(b.x + a.x, b.y + a.y)
        }
    } else f = u(a.Vd), e = a, a.targetTouches ? e = a.targetTouches[0] : f && a.n.targetTouches &&
        (e = a.n.targetTouches[0]), b.x = e.clientX, b.y = e.clientY;
    return b
}

function Xc(a, b, c) {
    b instanceof ob ? (c = b.height, b = b.width) : c == i && g(Error("missing height argument"));
    a.style.width = Qc(b, j);
    a.style.height = Qc(c, j)
}

function Qc(a, b) {
    "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
    return a
}

function Yc(a) {
    if ("none" != Oc(a, "display")) return Zc(a);
    var b = a.style,
        c = b.display,
        d = b.visibility,
        f = b.position;
    b.visibility = "hidden";
    b.position = "absolute";
    b.display = "inline";
    a = Zc(a);
    b.display = c;
    b.position = f;
    b.visibility = d;
    return a
}

function Zc(a) {
    var b = a.offsetWidth,
        c = a.offsetHeight,
        d = F && !b && !c;
    return (!da(b) || d) && a.getBoundingClientRect ? (a = Rc(a), new ob(a.right - a.left, a.bottom - a.top)) : new ob(b, c)
}

function $c(a) {
    var b = Tc(a),
        a = Yc(a);
    return new Lc(b.x, b.y, a.width, a.height)
}

function T(a, b) {
    var c = a.style;
    "opacity" in c ? c.opacity = b : "MozOpacity" in c ? c.MozOpacity = b : "filter" in c && (c.filter = "" === b ? "" : "alpha(opacity=" + 100 * b + ")")
}

function U(a, b) {
    a.style.display = b ? "" : "none"
}

function ad(a) {
    return "rtl" == Oc(a, "direction")
}
var bd = E ? "MozUserSelect" : F ? "WebkitUserSelect" : m;

function cd(a, b) {
    if (/^\d+px?$/.test(b)) return parseInt(b, 10);
    var c = a.style.left,
        d = a.runtimeStyle.left;
    a.runtimeStyle.left = a.currentStyle.left;
    a.style.left = b;
    var f = a.style.pixelLeft;
    a.style.left = c;
    a.runtimeStyle.left = d;
    return f
}

function dd(a, b) {
    if (D) {
        var c = cd(a, Nc(a, b + "Left")),
            d = cd(a, Nc(a, b + "Right")),
            f = cd(a, Nc(a, b + "Top")),
            e = cd(a, Nc(a, b + "Bottom"));
        return new Kc(f, d, e, c)
    }
    c = R(a, b + "Left");
    d = R(a, b + "Right");
    f = R(a, b + "Top");
    e = R(a, b + "Bottom");
    return new Kc(parseFloat(f), parseFloat(d), parseFloat(e), parseFloat(c))
}
var ed = {
    thin: 2,
    medium: 4,
    thick: 6
};

function fd(a, b) {
    if ("none" == Nc(a, b + "Style")) return 0;
    var c = Nc(a, b + "Width");
    return c in ed ? ed[c] : cd(a, c)
}

function gd(a) {
    if (D) {
        var b = fd(a, "borderLeft"),
            c = fd(a, "borderRight"),
            d = fd(a, "borderTop"),
            a = fd(a, "borderBottom");
        return new Kc(d, c, a, b)
    }
    b = R(a, "borderLeftWidth");
    c = R(a, "borderRightWidth");
    d = R(a, "borderTopWidth");
    a = R(a, "borderBottomWidth");
    return new Kc(parseFloat(d), parseFloat(c), parseFloat(a), parseFloat(b))
}
var Wc = /matrix\([0-9\.\-]+, [0-9\.\-]+, [0-9\.\-]+, [0-9\.\-]+, ([0-9\.\-]+)p?x?, ([0-9\.\-]+)p?x?\)/;

function hd(a, b, c) {
    nc.call(this);
    this.target = a;
    this.handle = b || a;
    this.wc = c || new Lc(NaN, NaN, NaN, NaN);
    this.L = J(a);
    this.ja = new Gc(this);
    N(this.handle, ["touchstart", "mousedown"], this.me, n, this)
}
v(hd, Jc);
var id = D || E && G("1.9.3");
q = hd.prototype;
q.clientX = 0;
q.clientY = 0;
q.screenX = 0;
q.screenY = 0;
q.Md = 0;
q.Nd = 0;
q.La = 0;
q.Ma = 0;
q.nd = j;
q.va = n;
q.Ad = 0;
q.ee = 0;
q.be = n;
q.Ic = n;
q.Eb = aa("ja");

function jd(a) {
    da(a.pa) || (a.pa = ad(a.target));
    return a.pa
}
q.me = function(a) {
    var b = "mousedown" == a.type;
    if (this.nd && !this.va && (!b || uc(a))) {
        kd(a);
        if (0 == this.Ad)
            if (this.dispatchEvent(new ld("start", this, a.clientX, a.clientY, a))) this.va = j, a.preventDefault();
            else return;
        else a.preventDefault();
        var b = this.L,
            c = b.documentElement,
            d = !id;
        P(this.ja, b, ["touchmove", "mousemove"], this.$d, d);
        P(this.ja, b, ["touchend", "mouseup"], this.Cb, d);
        id ? (c.setCapture(n), P(this.ja, c, "losecapture", this.Cb)) : P(this.ja, b ? b.parentWindow || b.defaultView : window, "blur", this.Cb);
        D && this.be && P(this.ja,
            b, "dragstart", qc);
        this.ke && P(this.ja, this.ke, "scroll", this.he, d);
        this.clientX = this.Md = a.clientX;
        this.clientY = this.Nd = a.clientY;
        this.screenX = a.screenX;
        this.screenY = a.screenY;
        this.Ic ? (a = this.target, b = a.offsetLeft, c = a.offsetParent, !c && "fixed" == Oc(a, "position") && (c = J(a).documentElement), c ? (E ? (d = gd(c), b += d.left) : eb(8) && (d = gd(c), b -= d.left), a = ad(c) ? c.clientWidth - (b + a.offsetWidth) : b) : a = b) : a = this.target.offsetLeft;
        this.La = a;
        this.Ma = this.target.offsetTop;
        this.Bc = Db(sb(this.L));
        this.ee = ra()
    } else this.dispatchEvent("earlycancel")
};
q.Cb = function(a, b) {
    this.ja.Rb();
    id && this.L.releaseCapture();
    if (this.va) {
        kd(a);
        this.va = n;
        var c = md(this, this.La),
            d = nd(this, this.Ma);
        this.dispatchEvent(new ld("end", this, a.clientX, a.clientY, a, c, d, b || "touchcancel" == a.type))
    } else this.dispatchEvent("earlycancel");
    ("touchend" == a.type || "touchcancel" == a.type) && a.preventDefault()
};

function kd(a) {
    var b = a.type;
    "touchstart" == b || "touchmove" == b ? a.init(a.n.targetTouches[0], a.currentTarget) : ("touchend" == b || "touchcancel" == b) && a.init(a.n.changedTouches[0], a.currentTarget)
}
q.$d = function(a) {
    if (this.nd) {
        kd(a);
        var b = (this.Ic && jd(this) ? -1 : 1) * (a.clientX - this.clientX),
            c = a.clientY - this.clientY;
        this.clientX = a.clientX;
        this.clientY = a.clientY;
        this.screenX = a.screenX;
        this.screenY = a.screenY;
        if (!this.va) {
            var d = this.Md - this.clientX,
                f = this.Nd - this.clientY;
            if (d * d + f * f > this.Ad)
                if (this.dispatchEvent(new ld("start", this, a.clientX, a.clientY, a))) this.va = j;
                else {
                    this.md || this.Cb(a);
                    return
                }
        }
        c = od(this, b, c);
        b = c.x;
        c = c.y;
        this.va && this.dispatchEvent(new ld("beforedrag", this, a.clientX, a.clientY, a,
            b, c)) && (pd(this, a, b, c), a.preventDefault())
    }
};

function od(a, b, c) {
    var d = Db(sb(a.L)),
        b = b + (d.x - a.Bc.x),
        c = c + (d.y - a.Bc.y);
    a.Bc = d;
    a.La += b;
    a.Ma += c;
    b = md(a, a.La);
    a = nd(a, a.Ma);
    return new I(b, a)
}
q.he = function(a) {
    var b = od(this, 0, 0);
    a.clientX = this.clientX;
    a.clientY = this.clientY;
    pd(this, a, b.x, b.y)
};

function pd(a, b, c, d) {
    a.ld(c, d);
    a.dispatchEvent(new ld("drag", a, b.clientX, b.clientY, b, c, d))
}

function md(a, b) {
    var c = a.wc,
        d = !isNaN(c.left) ? c.left : m,
        c = !isNaN(c.width) ? c.width : 0;
    return Math.min(d != m ? d + c : Infinity, Math.max(d != m ? d : -Infinity, b))
}

function nd(a, b) {
    var c = a.wc,
        d = !isNaN(c.top) ? c.top : m,
        c = !isNaN(c.height) ? c.height : 0;
    return Math.min(d != m ? d + c : Infinity, Math.max(d != m ? d : -Infinity, b))
}
q.ld = function(a, b) {
    this.Ic && jd(this) ? this.target.style.right = a + "px" : this.target.style.left = a + "px";
    this.target.style.top = b + "px"
};

function ld(a, b, c, d, f, e, h, k) {
    pc.call(this, a);
    this.clientX = c;
    this.clientY = d;
    this.re = f;
    this.left = da(e) ? e : b.La;
    this.top = da(h) ? h : b.Ma;
    this.ve = b;
    this.ue = !!k
}
v(ld, pc);

function qd(a) {
    for (var b = 0, c = 0; a && !isNaN(a.offsetLeft) && !isNaN(a.offsetTop);) b += a.offsetLeft - a.scrollLeft, c += a.offsetTop - a.scrollTop, a = a.offsetParent;
    return {
        top: c,
        left: b
    }
};

function rd() {
    this.$a = []
}
rd.prototype.addHandler = function(a, b) {
    this.$a[a] || (this.$a[a] = []);
    this.$a[a].push(b)
};
rd.prototype.Sb = function(a, b) {
    var c = this.$a[a];
    c && C(c, b)
};
rd.prototype.fireEvent = function(a, b, c) {
    var d = n;
    (a = this.$a[a]) && B(a, function(a) {
        a = a(b, c);
        da(a) && !a && (d = j)
    });
    return d
};

function sd(a, b) {
    this.X = {};
    this.h = [];
    var c = arguments.length;
    if (1 < c) {
        c % 2 && g(Error("Uneven number of arguments"));
        for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
    } else if (a) {
        var f;
        if (a instanceof sd) td(a), f = a.h.concat(), d = V(a);
        else {
            var c = [],
                e = 0;
            for (f in a) c[e++] = f;
            f = c;
            c = [];
            e = 0;
            for (d in a) c[e++] = a[d];
            d = c
        }
        for (c = 0; c < f.length; c++) this.set(f[c], d[c])
    }
}
q = sd.prototype;
q.m = 0;
q.Jc = 0;

function V(a) {
    td(a);
    for (var b = [], c = 0; c < a.h.length; c++) b.push(a.X[a.h[c]]);
    return b
}
q.clear = function() {
    this.X = {};
    this.Jc = this.m = this.h.length = 0
};
q.remove = function(a) {
    return ud(this.X, a) ? (delete this.X[a], this.m--, this.Jc++, this.h.length > 2 * this.m && td(this), j) : n
};

function td(a) {
    if (a.m != a.h.length) {
        for (var b = 0, c = 0; b < a.h.length;) {
            var d = a.h[b];
            ud(a.X, d) && (a.h[c++] = d);
            b++
        }
        a.h.length = c
    }
    if (a.m != a.h.length) {
        for (var f = {}, c = b = 0; b < a.h.length;) d = a.h[b], ud(f, d) || (a.h[c++] = d, f[d] = 1), b++;
        a.h.length = c
    }
}
q.get = function(a, b) {
    return ud(this.X, a) ? this.X[a] : b
};
q.set = function(a, b) {
    ud(this.X, a) || (this.m++, this.h.push(a), this.Jc++);
    this.X[a] = b
};

function ud(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b)
};

function W(a, b) {
    this.x = a;
    this.y = b
};

function vd(a) {
    this.points = a
}

function wd(a) {
    for (var b = 0, c = a.length - 1, d = 0; d < a.length; d++) b += (a[c].x + a[d].x) * (a[c].y - a[d].y), c = d;
    return b / 2
}

function xd(a, b) {
    for (var c, d = c = 0, f, e = a.length - 1, h = 0; h < a.length; h++) f = a[h].x * a[e].y - a[e].x * a[h].y, c += (a[h].x + a[e].x) * f, d += (a[h].y + a[e].y) * f, e = h;
    f = 6 * wd(a);
    c = new W(Math.abs(c / f), Math.abs(d / f));
    d = [];
    for (f = 0; f < a.length; f++) {
        var e = a[f],
            k = (0 > wd(a) ? -1 : 1) * b,
            h = e.x - c.x,
            l = e.y - c.y,
            r = 0 < k ? 1 : 0 > k ? -1 : 0,
            k = Math.sqrt(Math.pow(k, 2) / (1 + Math.pow(h / l, 2)));
        d.push({
            x: e.x + Math.abs(h / l * k) * (0 < h ? 1 : 0 > h ? -1 : 0) * r,
            y: e.y + Math.abs(k) * (0 < l ? 1 : 0 > l ? -1 : 0) * r
        })
    }
    return d
};

function yd(a, b, c, d) {
    0 < c ? (this.x = a, this.width = c) : (this.x = a + c, this.width = -c);
    0 < d ? (this.y = b, this.height = d) : (this.y = b + d, this.height = -d)
};

function zd(a, b, c, d) {
    this.type = a;
    this.geometry = b;
    c && (this.units = c);
    d && (this.style = d)
}

function Ad(a) {
    return "rect" == a.type ? a.geometry.width * a.geometry.height : "polygon" == a.type ? Math.abs(wd(a.geometry.points)) : 0
}

function Bd(a) {
    if ("rect" == a.type) return a;
    if ("polygon" == a.type) {
        for (var b = a.geometry.points, c = b[0].x, d = b[0].x, f = b[0].y, e = b[0].y, h = 1; h < b.length; h++) b[h].x > d && (d = b[h].x), b[h].x < c && (c = b[h].x), b[h].y > e && (e = b[h].y), b[h].y < f && (f = b[h].y);
        return new zd("rect", new yd(c, f, d - c, e - f), n, a.style)
    }
}

function Cd(a, b) {
    var c;
    c = a.geometry.points;
    var d = 0 > wd(c) ? -1 : 1;
    if (4 > c.length) c = xd(c, d * b);
    else {
        for (var f = c.length - 1, e = 1, h = [], k = 0; k < c.length; k++) f = xd([c[f], c[k], c[e]], d * b), h.push(f[1]), f = k, e++, e > c.length - 1 && (e = 0);
        c = h
    }
    return new zd("polygon", new vd(c), n, a.style)
}

function Dd(a, b) {
    if ("rect" == a.type) {
        var c = b(a.geometry);
        return new zd("rect", c, n, a.style)
    }
    if ("polygon" == a.type) {
        var d = [];
        B(a.geometry.points, function(a) {
            d.push(b(a))
        });
        return new zd("polygon", new vd(d), n, a.style)
    }
}

function Ed(a) {
    return JSON.stringify(a.geometry)
};

function Fd(a, b, c) {
    this.src = a;
    this.text = b;
    this.shapes = [c];
    this.context = document.URL
};

function Gd() {}

function Hd(a, b) {
    a.g = new sd;
    a.Vc = [];
    a.cb = [];
    a.Ha = [];
    a.Ea = [];
    a.Zb = [];
    a.vb = {
        Sa: n,
        Ra: n
    };
    a.Fa = new sd;
    a.ac = i;
    a.cd = b
}

function Id(a, b) {
    var c = a.Fa.get(b);
    c || (c = {
        Sa: n,
        Ra: n
    }, a.Fa.set(b, c));
    return c
}

function Jd(a, b) {
    var c = a.Fb(b);
    if (!a.g.get(c)) {
        var d = a.zc(b),
            f = [],
            e = [];
        B(a.Vc, function(a) {
            d.addHandler(a.type, a.Qa)
        });
        B(a.cb, function(a) {
            if (a.onInitAnnotator) a.onInitAnnotator(d)
        });
        B(a.Ea, function(a) {
            a.src == c && (d.G(a), f.push(a))
        });
        B(a.Zb, function(a) {
            a.src == c && (d.v(a), e.push(a))
        });
        B(f, function(b) {
            C(a.Ea, b)
        });
        B(e, function(b) {
            C(a.Zb, b)
        });
        var h = a.Fa.get(c);
        h ? (h.Sa && d.M(), h.Ra && d.ea(), a.Fa.remove(c)) : (a.vb.Sa && d.M(), a.vb.Ra && d.ea());
        a.ac && d.ga(a.ac);
        a.g.set(c, d);
        C(a.Ha, b)
    }
}

function Kd(a) {
    var b, c;
    for (c = a.Ha.length; 0 < c; c--) {
        for (var d = b = a.Ha[c - 1], f = d.offsetTop, e = d.offsetLeft, h = d.offsetWidth, k = d.offsetHeight; d.offsetParent;) d = d.offsetParent, f += d.offsetTop, e += d.offsetLeft;
        f < window.pageYOffset + window.innerHeight && (e < window.pageXOffset + window.innerWidth && f + k > window.pageYOffset && e + h > window.pageXOffset) && Jd(a, b)
    }
}

function Ld(a, b, c) {
    if (b) {
        var d = a.g.get(b);
        d ? c ? d.Ca() : d.ea() : Id(a, b).Ra = c
    } else B(V(a.g), function(a) {
        c ? a.Ca() : a.ea()
    }), a.vb.Ra = !c, B(V(a.Fa), function(a) {
        a.Ra = !c
    })
}

function Md(a, b, c) {
    if (b) {
        var d = a.g.get(b);
        d ? c ? d.Y() : d.M() : Id(a, b).Sa = c
    } else B(V(a.g), function(a) {
        c ? a.Y() : a.M()
    }), a.vb.Sa = !c, B(V(a.Fa), function(a) {
        a.Sa = !c
    })
}
q = Gd.prototype;
q.ba = function(a, b) {
    var c = i,
        d = i;
    t(a) ? (c = a, d = b) : u(a) && (d = a);
    c ? (c = this.g.get(c)) && c.ba(d) : B(V(this.g), function(a) {
        a.ba(d)
    })
};
q.G = function(a, b) {
    if (Nd(this, a.src)) {
        var c = this.g.get(a.src);
        c ? c.G(a, b) : (this.Ea.push(a), b && C(this.Ea, b))
    }
};
q.addHandler = function(a, b) {
    B(V(this.g), function(c) {
        c.addHandler(a, b)
    });
    this.Vc.push({
        type: a,
        Qa: b
    })
};
q.zb = function(a) {
    this.cb.push(a);
    B(V(this.g), function(b) {
        if (a.onInitAnnotator) a.onInitAnnotator(b)
    })
};

function Nd(a, b) {
    return ud(a.g.X, b) ? j : Ea(a.Ha, function(c) {
        return a.Fb(c) == b
    }) != m
}
q.destroy = function(a) {
    a ? (a = this.g.get(a)) && a.destroy() : (B(V(this.g), function(a) {
        a.destroy()
    }), this.g.clear())
};
q.xa = function(a) {
    if (Nd(this, a) && (a = this.g.get(a))) return a.xa().getName()
};
q.B = function(a) {
    if (a) {
        var b = this.g.get(a);
        return b ? b.B() : Ba(this.Ea, function(b) {
            return b.src == a
        })
    }
    var c = [];
    B(V(this.g), function(a) {
        Ha(c, a.B())
    });
    Ha(c, this.Ea);
    return c
};
q.ka = function(a) {
    if (Nd(this, a) && (a = this.g.get(a))) return Ca(a.ka(), function(a) {
        return a.getName()
    })
};
q.ea = function(a) {
    Ld(this, a, n)
};
q.M = function(a) {
    Md(this, a, n)
};
q.o = function(a) {
    if (a) {
        if (Nd(this, a.src)) {
            var b = this.g.get(a.src);
            b && b.o(a)
        }
    } else B(V(this.g), function(a) {
        a.o()
    })
};
q.init = function() {
    this.cd && Ha(this.Ha, this.cd());
    Kd(this);
    var a = this,
        b = N(window, "scroll", function() {
            0 < a.Ha.length ? Kd(a) : O(b)
        })
};
q.xc = function(a) {
    this.Vb(a) && Jd(this, a)
};
q.v = function(a) {
    if (Nd(this, a.src)) {
        var b = this.g.get(a.src);
        b ? b.v(a) : this.Zb.push(a)
    }
};
q.tb = function(a, b) {
    if (Nd(this, a)) {
        var c = this.g.get(a);
        c && c.Kd(b)
    }
};
q.ga = function(a) {
    this.ac = a;
    B(V(this.g), function(b) {
        b.ga(a)
    })
};
q.Ca = function(a) {
    Ld(this, a, j)
};
q.Y = function(a) {
    Md(this, a, j)
};

function Od(a, b) {
    var c = sb().createElement("DIV");
    c.innerHTML = a(b || Pd, i, i);
    if (1 == c.childNodes.length) {
        var d = c.firstChild;
        if (1 == d.nodeType) return d
    }
    return c
}
var Pd = {};

function Qd(a, b) {
    a != m && this.append.apply(this, arguments)
}
q = Qd.prototype;
q.ua = "";
q.set = function(a) {
    this.ua = "" + a
};
q.append = function(a, b, c) {
    this.ua += a;
    if (b != m)
        for (var d = 1; d < arguments.length; d++) this.ua += arguments[d];
    return this
};
q.clear = function() {
    this.ua = ""
};
q.toString = aa("ua");
/*
 Portions of this code are from the google-caja project, received by
 Google under the Apache license (http://code.google.com/p/google-caja/).
 All other code is Copyright 2009 Google, Inc. All Rights Reserved.

// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

*/
function Rd() {}
var Sd = {
        ze: "<",
        we: ">",
        pe: "&",
        Ae: "\u00a0",
        De: '"',
        qe: "'"
    },
    Td = {
        a: 0,
        abbr: 0,
        acronym: 0,
        address: 0,
        applet: 16,
        area: 2,
        b: 0,
        base: 18,
        basefont: 18,
        bdo: 0,
        big: 0,
        blockquote: 0,
        body: 49,
        br: 2,
        button: 0,
        caption: 0,
        center: 0,
        cite: 0,
        code: 0,
        col: 2,
        colgroup: 1,
        dd: 1,
        del: 0,
        dfn: 0,
        dir: 0,
        div: 0,
        dl: 0,
        dt: 1,
        em: 0,
        fieldset: 0,
        font: 0,
        form: 0,
        frame: 18,
        frameset: 16,
        h1: 0,
        h2: 0,
        h3: 0,
        h4: 0,
        h5: 0,
        h6: 0,
        head: 49,
        hr: 2,
        html: 49,
        i: 0,
        iframe: 20,
        img: 2,
        input: 2,
        ins: 0,
        isindex: 18,
        kbd: 0,
        label: 0,
        legend: 0,
        li: 1,
        link: 18,
        map: 0,
        menu: 0,
        meta: 18,
        noframes: 20,
        noscript: 20,
        object: 16,
        ol: 0,
        optgroup: 0,
        option: 1,
        p: 1,
        param: 18,
        pre: 0,
        q: 0,
        s: 0,
        samp: 0,
        script: 20,
        select: 0,
        small: 0,
        span: 0,
        strike: 0,
        strong: 0,
        style: 20,
        sub: 0,
        sup: 0,
        table: 0,
        tbody: 1,
        td: 1,
        textarea: 8,
        tfoot: 1,
        th: 1,
        thead: 1,
        title: 24,
        tr: 1,
        tt: 0,
        u: 0,
        ul: 0,
        "var": 0
    },
    Ud = /&/g,
    Vd = /&([^a-z#]|#(?:[^0-9x]|x(?:[^0-9a-f]|$)|$)|$)/gi,
    Wd = /</g,
    Xd = />/g,
    Yd = /\"/g,
    Zd = /=/g,
    $d = /\0/g,
    ae = /&(#\d+|#x[0-9A-Fa-f]+|\w+);/g,
    be = /^#(\d+)$/,
    ce = /^#x([0-9A-Fa-f]+)$/,
    de = RegExp("^\\s*(?:(?:([a-z][a-z-]*)(\\s*=\\s*(\"[^\"]*\"|'[^']*'|(?=[a-z][a-z-]*\\s*=)|[^>\"'\\s]*))?)|(/?>)|[^a-z\\s>]+)",
        "i"),
    ee = RegExp("^(?:&(\\#[0-9]+|\\#[x][0-9a-f]+|\\w+);|<[!]--[\\s\\S]*?--\>|<!\\w[^>]*>|<\\?[^>*]*>|<(/)?([a-z][a-z0-9]*)|([^<&>]+)|([<&>]))", "i");
Rd.prototype.parse = function(a, b) {
    var c = m,
        d = n,
        f = [],
        e, h, k;
    a.P = [];
    for (a.ma = n; b;) {
        var l = b.match(d ? de : ee),
            b = b.substring(l[0].length);
        if (d)
            if (l[1]) {
                var r = l[1].toLowerCase();
                if (l[2]) {
                    l = l[3];
                    switch (l.charCodeAt(0)) {
                        case 34:
                        case 39:
                            l = l.substring(1, l.length - 1)
                    }
                    l = l.replace($d, "").replace(ae, pa(this.ce, this))
                } else l = r;
                f.push(r, l)
            } else l[4] && (h !== i && (k ? a.Ld && a.Ld(e, f) : a.od && a.od(e)), k && h & 12 && (c = c === m ? b.toLowerCase() : c.substring(c.length - b.length), d = c.indexOf("</" + e), 0 > d && (d = b.length), h & 4 ? a.hd && a.hd(b.substring(0,
                d)) : a.Jd && a.Jd(b.substring(0, d).replace(Vd, "&amp;$1").replace(Wd, "&lt;").replace(Xd, "&gt;")), b = b.substring(d)), e = h = k = i, f.length = 0, d = n);
        else if (l[1]) fe(a, l[0]);
        else if (l[3]) k = !l[2], d = j, e = l[3].toLowerCase(), h = Td.hasOwnProperty(e) ? Td[e] : i;
        else if (l[4]) fe(a, l[4]);
        else if (l[5]) switch (l[5]) {
            case "<":
                fe(a, "&lt;");
                break;
            case ">":
                fe(a, "&gt;");
                break;
            default:
                fe(a, "&amp;")
        }
    }
    for (c = a.P.length; 0 <= --c;) a.ha.append("</", a.P[c], ">");
    a.P.length = 0
};
Rd.prototype.ce = function(a) {
    a = a.toLowerCase();
    if (Sd.hasOwnProperty(a)) return Sd[a];
    var b = a.match(be);
    return b ? String.fromCharCode(parseInt(b[1], 10)) : (b = a.match(ce)) ? String.fromCharCode(parseInt(b[1], 16)) : ""
};

function ge() {};
/*
 Portions of this code are from the google-caja project, received by
 Google under the Apache license (http://code.google.com/p/google-caja/).
 All other code is Copyright 2009 Google, Inc. All Rights Reserved.

// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

*/
function he(a, b, c) {
    this.ha = a;
    this.P = [];
    this.ma = n;
    this.Pd = b;
    this.Ob = c
}
v(he, ge);
var ie = {
    "*::class": 9,
    "*::dir": 0,
    "*::id": 4,
    "*::lang": 0,
    "*::onclick": 2,
    "*::ondblclick": 2,
    "*::onkeydown": 2,
    "*::onkeypress": 2,
    "*::onkeyup": 2,
    "*::onload": 2,
    "*::onmousedown": 2,
    "*::onmousemove": 2,
    "*::onmouseout": 2,
    "*::onmouseover": 2,
    "*::onmouseup": 2,
    "*::style": 3,
    "*::title": 0,
    "*::accesskey": 0,
    "*::tabindex": 0,
    "*::onfocus": 2,
    "*::onblur": 2,
    "a::coords": 0,
    "a::href": 1,
    "a::hreflang": 0,
    "a::name": 7,
    "a::onblur": 2,
    "a::rel": 0,
    "a::rev": 0,
    "a::shape": 0,
    "a::target": 10,
    "a::type": 0,
    "area::accesskey": 0,
    "area::alt": 0,
    "area::coords": 0,
    "area::href": 1,
    "area::nohref": 0,
    "area::onfocus": 2,
    "area::shape": 0,
    "area::tabindex": 0,
    "area::target": 10,
    "bdo::dir": 0,
    "blockquote::cite": 1,
    "br::clear": 0,
    "button::accesskey": 0,
    "button::disabled": 0,
    "button::name": 8,
    "button::onblur": 2,
    "button::onfocus": 2,
    "button::tabindex": 0,
    "button::type": 0,
    "button::value": 0,
    "caption::align": 0,
    "col::align": 0,
    "col::char": 0,
    "col::charoff": 0,
    "col::span": 0,
    "col::valign": 0,
    "col::width": 0,
    "colgroup::align": 0,
    "colgroup::char": 0,
    "colgroup::charoff": 0,
    "colgroup::span": 0,
    "colgroup::valign": 0,
    "colgroup::width": 0,
    "del::cite": 1,
    "del::datetime": 0,
    "dir::compact": 0,
    "div::align": 0,
    "dl::compact": 0,
    "font::color": 0,
    "font::face": 0,
    "font::size": 0,
    "form::accept": 0,
    "form::action": 1,
    "form::autocomplete": 0,
    "form::enctype": 0,
    "form::method": 0,
    "form::name": 7,
    "form::onreset": 2,
    "form::onsubmit": 2,
    "form::target": 10,
    "h1::align": 0,
    "h2::align": 0,
    "h3::align": 0,
    "h4::align": 0,
    "h5::align": 0,
    "h6::align": 0,
    "hr::align": 0,
    "hr::noshade": 0,
    "hr::size": 0,
    "hr::width": 0,
    "img::align": 0,
    "img::alt": 0,
    "img::border": 0,
    "img::height": 0,
    "img::hspace": 0,
    "img::ismap": 0,
    "img::longdesc": 1,
    "img::name": 7,
    "img::src": 1,
    "img::usemap": 11,
    "img::vspace": 0,
    "img::width": 0,
    "input::accept": 0,
    "input::accesskey": 0,
    "input::autocomplete": 0,
    "input::align": 0,
    "input::alt": 0,
    "input::checked": 0,
    "input::disabled": 0,
    "input::ismap": 0,
    "input::maxlength": 0,
    "input::name": 8,
    "input::onblur": 2,
    "input::onchange": 2,
    "input::onfocus": 2,
    "input::onselect": 2,
    "input::readonly": 0,
    "input::size": 0,
    "input::src": 1,
    "input::tabindex": 0,
    "input::type": 0,
    "input::usemap": 11,
    "input::value": 0,
    "ins::cite": 1,
    "ins::datetime": 0,
    "label::accesskey": 0,
    "label::for": 5,
    "label::onblur": 2,
    "label::onfocus": 2,
    "legend::accesskey": 0,
    "legend::align": 0,
    "li::type": 0,
    "li::value": 0,
    "map::name": 7,
    "menu::compact": 0,
    "ol::compact": 0,
    "ol::start": 0,
    "ol::type": 0,
    "optgroup::disabled": 0,
    "optgroup::label": 0,
    "option::disabled": 0,
    "option::label": 0,
    "option::selected": 0,
    "option::value": 0,
    "p::align": 0,
    "pre::width": 0,
    "q::cite": 1,
    "select::disabled": 0,
    "select::multiple": 0,
    "select::name": 8,
    "select::onblur": 2,
    "select::onchange": 2,
    "select::onfocus": 2,
    "select::size": 0,
    "select::tabindex": 0,
    "table::align": 0,
    "table::bgcolor": 0,
    "table::border": 0,
    "table::cellpadding": 0,
    "table::cellspacing": 0,
    "table::frame": 0,
    "table::rules": 0,
    "table::summary": 0,
    "table::width": 0,
    "tbody::align": 0,
    "tbody::char": 0,
    "tbody::charoff": 0,
    "tbody::valign": 0,
    "td::abbr": 0,
    "td::align": 0,
    "td::axis": 0,
    "td::bgcolor": 0,
    "td::char": 0,
    "td::charoff": 0,
    "td::colspan": 0,
    "td::headers": 6,
    "td::height": 0,
    "td::nowrap": 0,
    "td::rowspan": 0,
    "td::scope": 0,
    "td::valign": 0,
    "td::width": 0,
    "textarea::accesskey": 0,
    "textarea::cols": 0,
    "textarea::disabled": 0,
    "textarea::name": 8,
    "textarea::onblur": 2,
    "textarea::onchange": 2,
    "textarea::onfocus": 2,
    "textarea::onselect": 2,
    "textarea::readonly": 0,
    "textarea::rows": 0,
    "textarea::tabindex": 0,
    "tfoot::align": 0,
    "tfoot::char": 0,
    "tfoot::charoff": 0,
    "tfoot::valign": 0,
    "th::abbr": 0,
    "th::align": 0,
    "th::axis": 0,
    "th::bgcolor": 0,
    "th::char": 0,
    "th::charoff": 0,
    "th::colspan": 0,
    "th::headers": 6,
    "th::height": 0,
    "th::nowrap": 0,
    "th::rowspan": 0,
    "th::scope": 0,
    "th::valign": 0,
    "th::width": 0,
    "thead::align": 0,
    "thead::char": 0,
    "thead::charoff": 0,
    "thead::valign": 0,
    "tr::align": 0,
    "tr::bgcolor": 0,
    "tr::char": 0,
    "tr::charoff": 0,
    "tr::valign": 0,
    "ul::compact": 0,
    "ul::type": 0
};
he.prototype.Ld = function(a, b) {
    if (!this.ma && Td.hasOwnProperty(a)) {
        var c = Td[a];
        if (!(c & 32))
            if (c & 16) this.ma = !(c & 2);
            else {
                for (var d = b, f = 0; f < d.length; f += 2) {
                    var e = d[f],
                        h = d[f + 1],
                        k = m,
                        l;
                    if ((l = a + "::" + e, ie.hasOwnProperty(l)) || (l = "*::" + e, ie.hasOwnProperty(l))) k = ie[l];
                    if (k !== m) switch (k) {
                        case 0:
                            break;
                        case 2:
                        case 3:
                            h = m;
                            break;
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                        case 8:
                        case 9:
                            h = this.Ob ? this.Ob(h) : h;
                            break;
                        case 1:
                            h = this.Pd && this.Pd(h);
                            break;
                        case 11:
                            h && "#" === h.charAt(0) ? (h = this.Ob ? this.Ob(h) : h) && (h = "#" + h) : h = m;
                            break;
                        default:
                            h =
                                m
                    } else h = m;
                    d[f + 1] = h
                }
                if (b = d) {
                    c & 2 || this.P.push(a);
                    this.ha.append("<", a);
                    c = 0;
                    for (d = b.length; c < d; c += 2) f = b[c], e = b[c + 1], e !== m && e !== i && this.ha.append(" ", f, '="', e.replace(Ud, "&amp;").replace(Wd, "&lt;").replace(Xd, "&gt;").replace(Yd, "&#34;").replace(Zd, "&#61;"), '"');
                    this.ha.append(">")
                }
            }
    }
};
he.prototype.od = function(a) {
    if (this.ma) this.ma = n;
    else if (Td.hasOwnProperty(a)) {
        var b = Td[a];
        if (!(b & 50)) {
            if (b & 1)
                for (b = this.P.length; 0 <= --b;) {
                    var c = this.P[b];
                    if (c === a) break;
                    if (!(Td[c] & 1)) return
                } else
                    for (b = this.P.length; 0 <= --b && this.P[b] !== a;);
            if (!(0 > b)) {
                for (var d = this.P.length; --d > b;) c = this.P[d], Td[c] & 1 || this.ha.append("</", c, ">");
                this.P.length = b;
                this.ha.append("</", a, ">")
            }
        }
    }
};

function fe(a, b) {
    a.ma || a.ha.append(b)
}
he.prototype.Jd = function(a) {
    this.ma || this.ha.append(a)
};
he.prototype.hd = function(a) {
    this.ma || this.ha.append(a)
};

function je(a, b, c, d, f) {
    if (!D && (!F || !G("525"))) return j;
    if (Oa && f) return ke(a);
    if (f && !d || !c && (17 == b || 18 == b) || D && d && b == a) return n;
    switch (a) {
        case 13:
            return !(D && eb(9));
        case 27:
            return !F
    }
    return ke(a)
}

function ke(a) {
    if (48 <= a && 57 >= a || 96 <= a && 106 >= a || 65 <= a && 90 >= a || F && 0 == a) return j;
    switch (a) {
        case 32:
        case 63:
        case 107:
        case 109:
        case 110:
        case 111:
        case 186:
        case 59:
        case 189:
        case 187:
        case 61:
        case 188:
        case 190:
        case 191:
        case 192:
        case 222:
        case 219:
        case 220:
        case 221:
            return j;
        default:
            return n
    }
}

function le(a) {
    switch (a) {
        case 61:
            return 187;
        case 59:
            return 186;
        case 224:
            return 91;
        case 0:
            return 224;
        default:
            return a
    }
};

function me(a, b) {
    nc.call(this);
    a && ne(this, a, b)
}
v(me, Jc);
q = me.prototype;
q.A = m;
q.Ib = m;
q.uc = m;
q.Jb = m;
q.oa = -1;
q.na = -1;
q.mc = n;
var oe = {
        3: 13,
        12: 144,
        63232: 38,
        63233: 40,
        63234: 37,
        63235: 39,
        63236: 112,
        63237: 113,
        63238: 114,
        63239: 115,
        63240: 116,
        63241: 117,
        63242: 118,
        63243: 119,
        63244: 120,
        63245: 121,
        63246: 122,
        63247: 123,
        63248: 44,
        63272: 46,
        63273: 36,
        63275: 35,
        63276: 33,
        63277: 34,
        63289: 144,
        63302: 45
    },
    pe = {
        Up: 38,
        Down: 40,
        Left: 37,
        Right: 39,
        Enter: 13,
        F1: 112,
        F2: 113,
        F3: 114,
        F4: 115,
        F5: 116,
        F6: 117,
        F7: 118,
        F8: 119,
        F9: 120,
        F10: 121,
        F11: 122,
        F12: 123,
        "U+007F": 46,
        Home: 36,
        End: 35,
        PageUp: 33,
        PageDown: 34,
        Insert: 45
    },
    qe = D || F && G("525"),
    re = Oa && E;
q = me.prototype;
q.Xd = function(a) {
    if (F && (17 == this.oa && !a.ctrlKey || 18 == this.oa && !a.altKey)) this.na = this.oa = -1;
    qe && !je(a.keyCode, this.oa, a.shiftKey, a.ctrlKey, a.altKey) ? this.handleEvent(a) : (this.na = E ? le(a.keyCode) : a.keyCode, re && (this.mc = a.altKey))
};
q.Zd = function(a) {
    this.na = this.oa = -1;
    this.mc = a.altKey
};
q.handleEvent = function(a) {
    var b = a.n,
        c, d, f = b.altKey;
    D && "keypress" == a.type ? (c = this.na, d = 13 != c && 27 != c ? b.keyCode : 0) : F && "keypress" == a.type ? (c = this.na, d = 0 <= b.charCode && 63232 > b.charCode && ke(c) ? b.charCode : 0) : Ta ? (c = this.na, d = ke(c) ? b.keyCode : 0) : (c = b.keyCode || this.na, d = b.charCode || 0, re && (f = this.mc), Oa && (63 == d && 224 == c) && (c = 191));
    var e = c,
        h = b.keyIdentifier;
    c ? 63232 <= c && c in oe ? e = oe[c] : 25 == c && a.shiftKey && (e = 9) : h && h in pe && (e = pe[h]);
    a = e == this.oa;
    this.oa = e;
    b = new se(e, d, a, b);
    b.altKey = f;
    this.dispatchEvent(b)
};
q.d = aa("A");

function ne(a, b, c) {
    a.Jb && a.detach();
    a.A = b;
    a.Ib = N(a.A, "keypress", a, c);
    a.uc = N(a.A, "keydown", a.Xd, c, a);
    a.Jb = N(a.A, "keyup", a.Zd, c, a)
}
q.detach = function() {
    this.Ib && (O(this.Ib), O(this.uc), O(this.Jb), this.Jb = this.uc = this.Ib = m);
    this.A = m;
    this.na = this.oa = -1
};

function se(a, b, c, d) {
    d && this.init(d, i);
    this.type = "key";
    this.keyCode = a;
    this.charCode = b;
    this.repeat = c
}
v(se, sc);

function te() {}
fa(te);
te.prototype.ge = 0;
te.qb();

function ue(a) {
    nc.call(this);
    this.lb = a || sb();
    this.pa = ve
}
v(ue, Jc);
ue.prototype.ae = te.qb();
var ve = m;

function we(a, b) {
    switch (a) {
        case 1:
            return b ? "disable" : "enable";
        case 2:
            return b ? "highlight" : "unhighlight";
        case 4:
            return b ? "activate" : "deactivate";
        case 8:
            return b ? "select" : "unselect";
        case 16:
            return b ? "check" : "uncheck";
        case 32:
            return b ? "focus" : "blur";
        case 64:
            return b ? "open" : "close"
    }
    g(Error("Invalid component state"))
}
q = ue.prototype;
q.Hb = m;
q.fa = n;
q.A = m;
q.pa = m;
q.ya = m;
q.ib = m;
q.Ka = m;
q.oe = n;
q.d = aa("A");
q.Eb = function() {
    return this.sc || (this.sc = new Gc(this))
};
q.Hc = function(a) {
    this.ya && this.ya != a && g(Error("Method not supported"));
    ue.H.Hc.call(this, a)
};
q.qd = aa("lb");
q.kb = function(a) {
    this.fa && g(Error("Component already rendered"));
    if (a && this.hb(a)) {
        this.oe = j;
        if (!this.lb || this.lb.L != J(a)) this.lb = sb(a);
        this.kd(a);
        this.Na()
    } else g(Error("Invalid element to decorate"))
};
q.hb = ba(j);
q.kd = function(a) {
    this.A = a
};
q.Na = function() {
    function a(a) {
        !a.fa && a.d() && a.Na()
    }
    this.fa = j;
    this.ib && B(this.ib, a, i)
};
q.Db = function() {
    function a(a) {
        a.fa && a.Db()
    }
    this.ib && B(this.ib, a, i);
    this.sc && this.sc.Rb();
    this.fa = n
};
q.ob = aa("A");
q.Wa = function(a) {
    this.fa && g(Error("Component already rendered"));
    this.pa = a
};
q.removeChild = function(a, b) {
    if (a) {
        var c = t(a) ? a : a.Hb || (a.Hb = ":" + (a.ae.ge++).toString(36)),
            d;
        this.Ka && c ? (d = this.Ka, d = (c in d ? d[c] : i) || m) : d = m;
        a = d;
        c && a && (d = this.Ka, c in d && delete d[c], C(this.ib, a), b && (a.Db(), a.A && zb(a.A)), c = a, c == m && g(Error("Unable to set parent component")), c.ya = m, ue.H.Hc.call(c, m))
    }
    a || g(Error("Child is not in parent component"));
    return a
};

function xe() {}
var ye;
fa(xe);
q = xe.prototype;
q.ob = function(a) {
    return a
};
q.mb = function(a, b, c) {
    if (a = a.d ? a.d() : a)
        if (D && !G("7")) {
            var d = ze(ib(a), b);
            d.push(b);
            qa(c ? jb : lb, a).apply(m, d)
        } else c ? jb(a, b) : lb(a, b)
};
q.hb = ba(j);
q.kb = function(a, b) {
    if (b.id) {
        var c = b.id;
        if (a.ya && a.ya.Ka) {
            var d = a.ya.Ka,
                f = a.Hb;
            f in d && delete d[f];
            d = a.ya.Ka;
            c in d && g(Error('The object already contains the key "' + c + '"'));
            d[c] = a
        }
        a.Hb = c
    }(c = this.ob(b)) && c.firstChild ? (c = c.firstChild.nextSibling ? Ga(c.childNodes) : c.firstChild, a.jb = c) : a.jb = m;
    var e = 0,
        h = this.pb(),
        k = this.pb(),
        l = n,
        r = n,
        c = n,
        d = ib(b);
    B(d, function(a) {
        if (!l && a == h) l = j, k == h && (r = j);
        else if (!r && a == k) r = j;
        else {
            var b = e;
            if (!this.Od) {
                this.Bb || Ae(this);
                var c = this.Bb,
                    d = {},
                    f;
                for (f in c) d[c[f]] = f;
                this.Od = d
            }
            a =
                parseInt(this.Od[a], 10);
            e = b | (isNaN(a) ? 0 : a)
        }
    }, this);
    a.r = e;
    l || (d.push(h), k == h && (r = j));
    r || d.push(k);
    (f = a.da) && d.push.apply(d, f);
    if (D && !G("7")) {
        var w = ze(d);
        0 < w.length && (d.push.apply(d, w), c = j)
    }
    if (!l || !r || f || c) b.className = d.join(" ");
    a.isEnabled() || this.Xa(b, 1, j);
    a.r & 8 && this.Xa(b, 8, j);
    a.U & 16 && this.Xa(b, 16, !!(a.r & 16));
    a.U & 64 && this.Xa(b, 64, !!(a.r & 64));
    return b
};
q.Ub = function(a, b) {
    var c = !b,
        d = D || Ta ? a.getElementsByTagName("*") : m;
    if (bd) {
        if (c = c ? "none" : "", a.style[bd] = c, d)
            for (var f = 0, e; e = d[f]; f++) e.style[bd] = c
    } else if (D || Ta)
        if (c = c ? "on" : "", a.setAttribute("unselectable", c), d)
            for (f = 0; e = d[f]; f++) e.setAttribute("unselectable", c)
};
q.Wa = function(a, b) {
    this.mb(a, this.pb() + "-rtl", b)
};
q.Dd = function(a) {
    var b;
    return a.U & 32 && (b = a.Oa()) ? Cb(b) : n
};
q.Gc = function(a, b) {
    var c;
    if (a.U & 32 && (c = a.Oa())) {
        if (!b && a.r & 32) {
            try {
                c.blur()
            } catch (d) {}
            a.r & 32 && a.rd()
        }
        Cb(c) != b && (b ? c.tabIndex = 0 : (c.tabIndex = -1, c.removeAttribute("tabIndex")))
    }
};
q.O = function(a, b, c) {
    var d = a.d();
    if (d) {
        var f;
        this.Bb || Ae(this);
        (f = this.Bb[b]) && this.mb(a, f, c);
        this.Xa(d, b, c)
    }
};
q.Xa = function(a, b, c) {
    ye || (ye = {
        1: "disabled",
        8: "selected",
        16: "checked",
        64: "expanded"
    });
    (b = ye[b]) && a.setAttribute("aria-" + b, c)
};
q.qa = function(a, b) {
    var c = this.ob(a);
    if (c && (yb(c), b))
        if (t(b))
            if ("textContent" in c) c.textContent = b;
            else if (c.firstChild && 3 == c.firstChild.nodeType) {
        for (; c.lastChild != c.firstChild;) c.removeChild(c.lastChild);
        c.firstChild.data = b
    } else yb(c), c.appendChild(J(c).createTextNode(b));
    else {
        var d = function(a) {
            if (a) {
                var b = J(c);
                c.appendChild(t(a) ? b.createTextNode(a) : a)
            }
        };
        ha(b) ? B(b, d) : ia(b) && !("nodeType" in b) ? B(Ga(b), d) : d(b)
    }
};
q.Oa = function(a) {
    return a.d()
};
q.pb = ba("goog-control");

function ze(a, b) {
    var c = [];
    b && (a = a.concat([b]));
    B([], function(d) {
        Da(d, qa(Fa, a)) && (!b || Fa(d, b)) && c.push(d.join("_"))
    });
    return c
}

function Ae(a) {
    var b = a.pb();
    a.Bb = {
        1: b + "-disabled",
        2: b + "-hover",
        4: b + "-active",
        8: b + "-selected",
        16: b + "-checked",
        32: b + "-focused",
        64: b + "-open"
    }
};
var Be = {};

function Ce(a, b, c) {
    ue.call(this, c);
    if (!b) {
        for (var b = this.constructor, d; b;) {
            d = ka(b);
            if (d = Be[d]) break;
            b = b.H ? b.H.constructor : m
        }
        b = d ? u(d.qb) ? d.qb() : new d : m
    }
    this.C = b;
    this.jb = a
}
v(Ce, ue);
q = Ce.prototype;
q.jb = m;
q.r = 0;
q.U = 39;
q.oc = 255;
q.ne = 0;
q.Xb = j;
q.da = m;
q.tc = j;
q.lc = n;
q.je = m;

function De(a) {
    a.fa && n != a.tc && Ee(a, n);
    a.tc = n
}
q.Oa = function() {
    return this.C.Oa(this)
};
q.mb = function(a, b) {
    b ? a && (this.da ? Fa(this.da, a) || this.da.push(a) : this.da = [a], this.C.mb(this, a, j)) : a && this.da && (C(this.da, a), 0 == this.da.length && (this.da = m), this.C.mb(this, a, n))
};
q.ob = function() {
    return this.C.ob(this.d())
};
q.hb = function(a) {
    return this.C.hb(a)
};
q.kd = function(a) {
    this.A = a = this.C.kb(this, a);
    var b = this.je || i;
    b && a.setAttribute("role", b);
    this.lc || this.C.Ub(a, n);
    this.Xb = "none" != a.style.display
};
q.Na = function() {
    Ce.H.Na.call(this);
    var a = this.C;
    this.pa == m && (this.pa = ad(this.fa ? this.A : this.lb.L.body));
    this.pa && a.Wa(this.d(), j);
    this.isEnabled() && a.Gc(this, this.Xb);
    if (this.U & -2 && (this.tc && Ee(this, j), this.U & 32 && (a = this.Oa()))) {
        var b = this.vc || (this.vc = new me);
        ne(b, a);
        P(P(P(this.Eb(), b, "key", this.Yd), a, "focus", this.Wd), a, "blur", this.rd)
    }
};

function Ee(a, b) {
    var c = a.Eb(),
        d = a.d();
    b ? (P(P(P(P(c, d, "mouseover", a.wd), d, "mousedown", a.ud), d, "mouseup", a.xd), d, "mouseout", a.vd), a.Gb != ea && P(c, d, "contextmenu", a.Gb), D && P(c, d, "dblclick", a.sd)) : (Ic(Ic(Ic(Ic(c, d, "mouseover", a.wd), d, "mousedown", a.ud), d, "mouseup", a.xd), d, "mouseout", a.vd), a.Gb != ea && Ic(c, d, "contextmenu", a.Gb), D && Ic(c, d, "dblclick", a.sd))
}
q.Db = function() {
    Ce.H.Db.call(this);
    this.vc && this.vc.detach();
    this.Xb && this.isEnabled() && this.C.Gc(this, n)
};
q.qa = function(a) {
    this.C.qa(this.d(), a);
    this.jb = a
};
q.Wa = function(a) {
    Ce.H.Wa.call(this, a);
    var b = this.d();
    b && this.C.Wa(b, a)
};
q.Ub = function(a) {
    this.lc = a;
    var b = this.d();
    b && this.C.Ub(b, a)
};
q.isEnabled = function() {
    return !(this.r & 1)
};

function Fe(a, b) {
    Ge(a, 2, b) && a.O(2, b)
}
q.setActive = function(a) {
    Ge(this, 4, a) && this.O(4, a)
};
q.O = function(a, b) {
    this.U & a && b != !!(this.r & a) && (this.C.O(this, a, b), this.r = b ? this.r | a : this.r & ~a)
};

function X(a, b) {
    return !!(a.oc & b) && !!(a.U & b)
}

function Ge(a, b, c) {
    return !!(a.U & b) && !!(a.r & b) != c && (!(a.ne & b) || a.dispatchEvent(we(b, c))) && !a.md
}
q.wd = function(a) {
    (!a.relatedTarget || !Bb(this.d(), a.relatedTarget)) && (this.dispatchEvent("enter") && this.isEnabled() && X(this, 2)) && Fe(this, j)
};
q.vd = function(a) {
    if ((!a.relatedTarget || !Bb(this.d(), a.relatedTarget)) && this.dispatchEvent("leave")) X(this, 4) && this.setActive(n), X(this, 2) && Fe(this, n)
};
q.Gb = ea;
q.ud = function(a) {
    this.isEnabled() && (X(this, 2) && Fe(this, j), uc(a) && (X(this, 4) && this.setActive(j), this.C.Dd(this) && this.Oa().focus()));
    !this.lc && uc(a) && a.preventDefault()
};
q.xd = function(a) {
    this.isEnabled() && (X(this, 2) && Fe(this, j), this.r & 4 && (He(this, a) && X(this, 4)) && this.setActive(n))
};
q.sd = function(a) {
    this.isEnabled() && He(this, a)
};

function He(a, b) {
    if (X(a, 16)) {
        var c = !(a.r & 16);
        Ge(a, 16, c) && a.O(16, c)
    }
    X(a, 8) && Ge(a, 8, j) && a.O(8, j);
    X(a, 64) && (c = !(a.r & 64), Ge(a, 64, c) && a.O(64, c));
    c = new pc("action", a);
    b && (c.altKey = b.altKey, c.ctrlKey = b.ctrlKey, c.metaKey = b.metaKey, c.shiftKey = b.shiftKey, c.Dc = b.Dc);
    return a.dispatchEvent(c)
}
q.Wd = function() {
    X(this, 32) && Ge(this, 32, j) && this.O(32, j)
};
q.rd = function() {
    X(this, 4) && this.setActive(n);
    X(this, 32) && Ge(this, 32, n) && this.O(32, n)
};
q.Yd = function(a) {
    return this.Xb && this.isEnabled() && 13 == a.keyCode && He(this, a) ? (a.preventDefault(), a.stopPropagation(), j) : n
};
u(Ce) || g(Error("Invalid component class " + Ce));
u(xe) || g(Error("Invalid renderer class " + xe));
var Ie = ka(Ce);
Be[Ie] = xe;

function Ke() {
    return new Ce(m)
}
u(Ke) || g(Error("Invalid decorator function " + Ke));

function Le() {}
v(Le, xe);
fa(Le);
q = Le.prototype;
q.kb = function(a, b) {
    De(a);
    a.oc &= -256;
    a.fa && a.r & 32 && g(Error("Component already rendered"));
    a.r & 32 && a.O(32, n);
    a.U &= -33;
    Le.H.kb.call(this, a, b);
    a.qa(b.value);
    return b
};
q.hb = function(a) {
    return "TEXTAREA" == a.tagName
};
q.Wa = ea;
q.Dd = function(a) {
    return a.isEnabled()
};
q.Gc = ea;
q.O = function(a, b, c) {
    Le.H.O.call(this, a, b, c);
    if ((a = a.d()) && 1 == b) a.disabled = c
};
q.Xa = ea;
q.qa = function(a, b) {
    a && (a.value = b)
};
q.pb = ba("goog-textarea");

function Me(a, b, c) {
    Ce.call(this, a, b || Le.qb(), c);
    De(this);
    this.Ub(j);
    a || (this.jb = "")
}
v(Me, Ce);
var Ne = E || F;
q = Me.prototype;
q.Ta = n;
q.la = 0;
q.de = 0;
q.Gd = 0;
q.zd = n;
q.Nb = n;
q.Fc = n;
q.Ec = n;

function Oe(a) {
    return a.sb.top + a.sb.bottom + a.fd.top + a.fd.bottom
}

function Pe(a) {
    var b = a.Gd,
        c = a.d();
    b && (c && a.Nb) && (b -= Oe(a));
    return b
}

function Qe(a) {
    var b = a.de,
        c = a.d();
    b && (c && a.Nb) && (b -= Oe(a));
    return b
}
q.qa = function(a) {
    Me.H.qa.call(this, a);
    this.d() && this.Pa()
};
q.Na = function() {
    Me.H.Na.call(this);
    var a = this.d();
    Q(a, {
        overflowY: "hidden",
        overflowX: "auto",
        boxSizing: "border-box",
        MsBoxSizing: "border-box",
        WebkitBoxSizing: "border-box",
        MozBoxSizing: "border-box"
    });
    this.sb = dd(a, "padding");
    this.fd = gd(a);
    P(P(P(P(this.Eb(), a, "scroll", this.Pa), a, "focus", this.Pa), a, "keyup", this.Pa), a, "mouseup", this.fe);
    this.d() && this.Pa()
};

function Re(a) {
    if (!a.zd) {
        var b = a.d().cloneNode(n);
        Q(b, {
            position: "absolute",
            height: "auto",
            top: "-9999px",
            margin: "0",
            padding: "1px",
            border: "1px solid #000",
            overflow: "hidden"
        });
        a.qd().L.body.appendChild(b);
        var c = b.scrollHeight;
        b.style.padding = "10px";
        var d = b.scrollHeight;
        a.Fc = d > c;
        b.style.borderWidth = "10px";
        a.Ec = b.scrollHeight > d;
        b.style.height = "100px";
        100 != b.offsetHeight && (a.Nb = j);
        zb(b);
        a.zd = j
    }
    var b = a.d(),
        c = a.d().scrollHeight,
        f = a.d(),
        d = f.offsetHeight - f.clientHeight;
    if (!a.Fc) var e = a.sb,
        d = d - (e.top + e.bottom);
    a.Ec || (f = gd(f), d -= f.top + f.bottom);
    c += 0 < d ? d : 0;
    a.Nb ? c -= Oe(a) : (a.Fc || (d = a.sb, c += d.top + d.bottom), a.Ec || (a = gd(b), c += a.top + a.bottom));
    return c
}

function Se(a, b) {
    a.la != b && (a.la = b, a.d().style.height = b + "px")
}

function Te(a) {
    a = a.d();
    a.style.height = "auto";
    var b = a.value.match(/\n/g) || [];
    a.rows = b.length + 1
}
q.Pa = function() {
    if (!this.Ta) {
        var a = n;
        this.Ta = j;
        var b = this.d(),
            c = this.la;
        if (b.scrollHeight) {
            var d = n,
                f = n,
                e = Re(this),
                h = b.offsetHeight,
                k = Pe(this),
                l = Qe(this);
            k && e < k ? (Se(this, k), d = j) : l && e > l ? (Se(this, l), b.style.overflowY = "", f = j) : h != e ? Se(this, e) : this.la || (this.la = e);
            !d && (!f && Ne) && (a = j)
        } else Te(this);
        this.Ta = n;
        a && (a = this.d(), this.Ta || (this.Ta = j, b = n, a.value || (a.value = " ", b = j), (f = a.scrollHeight) ? (e = Re(this), d = Pe(this), h = Qe(this), !(d && e <= d) && !(h && e >= h) && (h = this.sb, a.style.paddingBottom = h.bottom + 1 + "px", Re(this) ==
            e && (a.style.paddingBottom = h.bottom + f + "px", a.scrollTop = 0, f = Re(this) - f, f >= d ? Se(this, f) : Se(this, d)), a.style.paddingBottom = h.bottom + "px")) : Te(this), b && (a.value = ""), this.Ta = n));
        c != this.la && this.dispatchEvent("resize")
    }
};
q.fe = function() {
    var a = this.d(),
        b = a.offsetHeight;
    a.filters && a.filters.length && (a = a.filters.item("DXImageTransform.Microsoft.DropShadow")) && (b -= a.offX);
    b != this.la && (this.la = this.Gd = b)
};
D && G(8);

function Ue(a) {
    return "object" === typeof a && a && 0 === a.se ? a.content : String(a).replace(Ve, We)
}
var Xe = {
    "\x00": "&#0;",
    '"': "&quot;",
    "&": "&amp;",
    "'": "&#39;",
    "<": "&lt;",
    ">": "&gt;",
    "\t": "&#9;",
    "\n": "&#10;",
    "\x0B": "&#11;",
    "\f": "&#12;",
    "\r": "&#13;",
    " ": "&#32;",
    "-": "&#45;",
    "/": "&#47;",
    "=": "&#61;",
    "`": "&#96;",
    "\u0085": "&#133;",
    "\u00a0": "&#160;",
    "\u2028": "&#8232;",
    "\u2029": "&#8233;"
};

function We(a) {
    return Xe[a]
}
var Ve = /[\x00\x22\x26\x27\x3c\x3e]/g;

function Ye() {
    return '<div class="annotorious-popup top-left" style="position:absolute;z-index:1"><div class="annotorious-popup-buttons"><a class="annotorious-popup-button annotorious-popup-button-edit" title="Edit" href="javascript:void(0);">EDIT</a><a class="annotorious-popup-button annotorious-popup-button-delete" title="Delete" href="javascript:void(0);">DELETE</a></div><span class="annotorious-popup-text"></span></div>'
}

function Ze() {
    return '<div class="annotorious-editor" style="position:absolute;z-index:1"><form><textarea class="annotorious-editor-text" placeholder="Add a Comment..." tabindex="1"></textarea><div class="annotorious-editor-button-container"><a class="annotorious-editor-button annotorious-editor-button-cancel" href="javascript:void(0);" tabindex="3">Cancel</a><a class="annotorious-editor-button annotorious-editor-button-save" href="javascript:void(0);" tabindex="2">Save</a></div></form></div>'
};

function $e(a) {
    function b() {
        var a = d.Ja;
        a.d() && a.Pa()
    }
    this.element = Od(Ze);
    this.e = a;
    this.Sd = a.getItem();
    this.Ja = new Me("");
    this.Qd = K(".annotorious-editor-button-cancel", this.element)[0];
    this.Uc = K(".annotorious-editor-button-save", this.element)[0];
    var c;
    c = this.Uc;
    hb ? c = c.parentElement : (c = c.parentNode, c = Ab(c) ? c : m);
    this.Rd = c;
    this.Za = [];
    var d = this;
    N(this.Qd, "click", function(b) {
        b.preventDefault();
        a.stopSelection(d.ad);
        d.close()
    });
    N(this.Uc, "click", function(b) {
        b.preventDefault();
        b = d.pd();
        a.G(b);
        a.stopSelection();
        d.ad ? a.fireEvent("onAnnotationUpdated", b, a.getItem()) : a.fireEvent("onAnnotationCreated", b, a.getItem());
        d.close()
    });
    U(this.element, n);
    a.element.appendChild(this.element);
    this.Ja.kb(K(".annotorious-editor-text", this.element)[0]);
    var f = this.element;
    c = document.createElement("div");
    Q(c, "position", "absolute");
    Q(c, "top", "0px");
    Q(c, "right", "0px");
    Q(c, "width", "5px");
    Q(c, "height", "100%");
    Q(c, "cursor", "e-resize");
    f.appendChild(c);
    var e = gd(f),
        e = $c(f).width - e.right - e.left;
    c = new hd(c);
    c.wc = new Lc(e, 0, 800, 0) || new Lc(NaN,
        NaN, NaN, NaN);
    c.ld = function(a) {
        Q(f, "width", a + "px");
        b && b()
    }
}
q = $e.prototype;
q.kc = function(a) {
    var b = wb("div", "annotorious-editor-field");
    t(a) ? b.innerHTML = a : u(a) ? this.Za.push({
        z: b,
        qc: a
    }) : Ab(a) && b.appendChild(a);
    a = this.Rd;
    a.parentNode && a.parentNode.insertBefore(b, a)
};
q.open = function(a) {
    (this.wb = this.ad = a) && this.Ja.qa(String(a.text));
    U(this.element, j);
    this.Ja.d().focus();
    B(this.Za, function(b) {
        var c = b.qc(a);
        t(c) ? b.z.innerHTML = c : Ab(c) && (yb(b.z), b.z.appendChild(c))
    });
    this.e.fireEvent("onEditorShown", a)
};
q.close = function() {
    U(this.element, n);
    this.Ja.qa("")
};
q.setPosition = function(a) {
    Pc(this.element, a.x, a.y)
};
q.pd = function() {
    var a;
    a = this.Ja.d().value;
    var b = new Qd;
    (new Rd).parse(new he(b, function(a) {
        return a
    }, i), a);
    a = b.toString();
    this.wb ? this.wb.text = a : this.wb = new Fd(this.Sd.src, a, this.e.xa().getShape());
    return this.wb
};
$e.prototype.addField = $e.prototype.kc;
$e.prototype.getAnnotation = $e.prototype.pd;

function af(a, b, c) {
    var d = this;
    c || (c = "Click and Drag to Annotate");
    this.element = Od(bf, {
        Mb: c
    });
    this.e = a;
    this.Yc = K(".annotorious-hint-msg", this.element)[0];
    this.Wc = K(".annotorious-hint-icon", this.element)[0];
    this.hc = function() {
        d.show()
    };
    this.gc = function() {
        cf(d)
    };
    this.Yb();
    cf(this);
    b.appendChild(this.element)
}
af.prototype.Yb = function() {
    var a = this;
    this.$c = N(this.Wc, "mouseover", function() {
        a.show();
        window.clearTimeout(a.dc)
    });
    this.Zc = N(this.Wc, "mouseout", function() {
        cf(a)
    });
    this.e.addHandler("onMouseOverItem", this.hc);
    this.e.addHandler("onMouseOutOfItem", this.gc)
};
af.prototype.xb = function() {
    O(this.$c);
    O(this.Zc);
    this.e.Sb("onMouseOverItem", this.hc);
    this.e.Sb("onMouseOutOfItem", this.gc)
};
af.prototype.show = function() {
    window.clearTimeout(this.dc);
    T(this.Yc, 0.8);
    var a = this;
    this.dc = window.setTimeout(function() {
        cf(a)
    }, 3E3)
};

function cf(a) {
    window.clearTimeout(a.dc);
    T(a.Yc, 0)
}
af.prototype.destroy = function() {
    this.xb();
    delete this.$c;
    delete this.Zc;
    delete this.hc;
    delete this.gc;
    zb(this.element)
};

function df(a) {
    this.element = Od(Ye);
    this.e = a;
    this.Td = K(".annotorious-popup-text", this.element)[0];
    this.Q = K(".annotorious-popup-buttons", this.element)[0];
    this.bc = n;
    this.Za = [];
    var b = K(".annotorious-popup-button-edit", this.Q)[0],
        c = K(".annotorious-popup-button-delete", this.Q)[0],
        d = this;
    N(b, "mouseover", function() {
        jb(b, "annotorious-popup-button-active")
    });
    N(b, "mouseout", function() {
        lb(b, "annotorious-popup-button-active")
    });
    N(b, "click", function() {
        T(d.element, 0);
        Q(d.element, "pointer-events", "none");
        a.pc(d.f)
    });
    N(c, "mouseover", function() {
        jb(c, "annotorious-popup-button-active")
    });
    N(c, "mouseout", function() {
        lb(c, "annotorious-popup-button-active")
    });
    N(c, "click", function() {
        a.fireEvent("beforeAnnotationRemoved", d.f) || (T(d.element, 0), Q(d.element, "pointer-events", "none"), a.v(d.f), a.fireEvent("onAnnotationRemoved", d.f))
    });
    ef && (N(this.element, "mouseover", function() {
            window.clearTimeout(d.$b);
            0.9 > (d.Q.style[za("opacity")] || "") && T(d.Q, 0.9);
            d.clearHideTimer()
        }), N(this.element, "mouseout", function() {
            T(d.Q, 0);
            d.startHideTimer()
        }),
        a.addHandler("onMouseOutOfItem", function() {
            d.startHideTimer()
        }));
    T(this.Q, 0);
    T(this.element, 0);
    Q(this.element, "pointer-events", "none");
    a.element.appendChild(this.element)
}
q = df.prototype;
q.kc = function(a) {
    var b = wb("div", "annotorious-popup-field");
    t(a) ? b.innerHTML = a : u(a) ? this.Za.push({
        z: b,
        qc: a
    }) : Ab(a) && b.appendChild(a);
    this.element.appendChild(b)
};
q.startHideTimer = function() {
    this.bc = n;
    if (!this.eb) {
        var a = this;
        this.eb = window.setTimeout(function() {
            a.e.fireEvent("beforePopupHide", a);
            a.bc || (T(a.element, 0), Q(a.element, "pointer-events", "none"), T(a.Q, 0.9), delete a.eb)
        }, 150)
    }
};
q.clearHideTimer = function() {
    this.bc = j;
    this.eb && (window.clearTimeout(this.eb), delete this.eb)
};
q.show = function(a, b) {
    this.clearHideTimer();
    b && this.setPosition(b);
    a && this.setAnnotation(a);
    this.$b && window.clearTimeout(this.$b);
    T(this.Q, 0.9);
    if (ef) {
        var c = this;
        this.$b = window.setTimeout(function() {
            T(c.Q, 0)
        }, 1E3)
    }
    T(this.element, 0.9);
    Q(this.element, "pointer-events", "auto");
    this.e.fireEvent("onPopupShown", a)
};
q.setPosition = function(a) {
    Pc(this.element, new I(a.x, a.y))
};
q.setAnnotation = function(a) {
    this.f = a;
    this.Td.innerHTML = a.text ? a.text.replace(/\n/g, "<br/>") : '<span class="annotorious-popup-empty">No comment</span>';
    "editable" in a && a.editable == n ? U(this.Q, n) : U(this.Q, j);
    B(this.Za, function(b) {
        var c = b.qc(a);
        t(c) ? b.z.innerHTML = c : Ab(c) && (yb(b.z), b.z.appendChild(c))
    })
};
df.prototype.addField = df.prototype.kc;

function ff() {}
q = ff.prototype;
q.G = function(a) {
    this.k.G(a)
};
q.addHandler = function(a, b) {
    this.t.addHandler(a, b)
};
q.fireEvent = function(a, b, c) {
    return this.t.fireEvent(a, b, c)
};
q.xa = aa("T");
q.o = function(a) {
    this.k.o(a)
};
q.v = function(a) {
    this.k.v(a)
};
q.Sb = function(a, b) {
    this.t.Sb(a, b)
};
q.stopSelection = function(a) {
    U(this.c, n);
    this.fb && (this.fb(), delete this.fb);
    this.T.stopSelection();
    a && this.k.G(a)
};

function gf(a, b) {
    this.Z = a;
    this.e = b;
    this.Da = [];
    this.aa = [];
    this.sa = this.Z.getContext("2d");
    this.ra = j;
    this.yb = n;
    var c = this;
    N(this.Z, hf, function(a) {
        if (c.ra) {
            var b = jf(c, a.offsetX, a.offsetY);
            b ? (c.yb = c.yb && b == c.f, c.f ? c.f != b && (c.ra = n, c.e.popup.startHideTimer()) : (c.f = b, kf(c), c.e.fireEvent("onMouseOverAnnotation", {
                K: c.f,
                mouseEvent: a
            }))) : !c.yb && c.f && (c.ra = n, c.e.popup.startHideTimer())
        } else c.Ya = a
    });
    b.addHandler("onMouseOutOfItem", function() {
        delete c.f;
        c.ra = j
    });
    b.addHandler("beforePopupHide", function() {
        if (!c.ra &&
            c.Ya) {
            var a = c.f;
            c.f = jf(c, c.Ya.offsetX, c.Ya.offsetY);
            c.ra = j;
            a != c.f ? (kf(c), c.e.fireEvent("onMouseOutOfAnnotation", {
                K: a,
                mouseEvent: c.Ya
            }), c.e.fireEvent("onMouseOverAnnotation", {
                K: c.f,
                mouseEvent: c.Ya
            })) : c.f && c.e.popup.clearHideTimer()
        } else kf(c)
    })
}
q = gf.prototype;
q.G = function(a, b) {
    b && (b == this.f && delete this.f, C(this.Da, b), delete this.aa[Ed(b.shapes[0])]);
    this.Da.push(a);
    var c = a.shapes[0];
    if ("pixel" != c.units) var d = this,
        c = Dd(c, function(a) {
            return d.e.wa(a)
        });
    this.aa[Ed(a.shapes[0])] = c;
    kf(this)
};
q.v = function(a) {
    a == this.f && delete this.f;
    C(this.Da, a);
    delete this.aa[Ed(a.shapes[0])];
    kf(this)
};
q.B = function() {
    return Ga(this.Da)
};
q.o = function(a) {
    (this.f = a) ? this.yb = j: this.e.popup.startHideTimer();
    kf(this);
    this.ra = j
};

function jf(a, b, c) {
    a = a.nb(b, c);
    if (0 < a.length) return a[0]
}
q.nb = function(a, b) {
    var c = [],
        d = this;
    B(this.Da, function(f) {
        var e;
        e = d.aa[Ed(f.shapes[0])];
        if ("rect" == e.type) e = a < e.geometry.x || b < e.geometry.y || a > e.geometry.x + e.geometry.width || b > e.geometry.y + e.geometry.height ? n : j;
        else if ("polygon" == e.type) {
            e = e.geometry.points;
            for (var h = n, k = e.length - 1, l = 0; l < e.length; l++) e[l].y > b != e[k].y > b && a < (e[k].x - e[l].x) * (b - e[l].y) / (e[k].y - e[l].y) + e[l].x && (h = !h), k = l;
            e = h
        } else e = n;
        e && c.push(f)
    });
    z.sort.call(c, function(a, b) {
        var c = d.aa[Ed(a.shapes[0])],
            k = d.aa[Ed(b.shapes[0])];
        return Ad(c) -
            Ad(k)
    } || Ja);
    return c
};

function lf(a, b, c) {
    var d = Ea(a.e.ka(), function(a) {
        return a.getSupportedShapeType() == b.type
    });
    d ? d.drawShape(a.sa, b, c) : console.log("WARNING unsupported shape type: " + b.type)
}

function kf(a) {
    a.sa.clearRect(0, 0, a.Z.width, a.Z.height);
    B(a.Da, function(b) {
        b != a.f && lf(a, a.aa[Ed(b.shapes[0])])
    });
    if (a.f) {
        var b = a.aa[Ed(a.f.shapes[0])];
        lf(a, b, j);
        b = Bd(b).geometry;
        a.e.popup.show(a.f, new W(b.x, b.y + b.height + 5))
    }
};
var mf = "ontouchstart" in window,
    ef = !mf,
    nf = mf ? "touchstart" : "mousedown",
    of = mf ? "touchenter" : "mouseover",
    hf = mf ? "touchmove" : "mousemove",
    pf = mf ? "touchend" : "mouseup",
    qf = mf ? "touchleave" : "mouseout";

function rf(a, b) {
    var c = n;
    a.offsetX = a.offsetX ? a.offsetX : n;
    a.offsetY = a.offsetY ? a.offsetY : n;
    return c = (!a.offsetX || !a.offsetY) && a.n.changedTouches ? {
        x: a.n.changedTouches[0].clientX - qd(b).left,
        y: a.n.changedTouches[0].clientY - qd(b).top
    } : {
        x: a.offsetX,
        y: a.offsetY
    }
};

function sf() {}
q = sf.prototype;
q.init = function(a, b) {
    this.Qc = "#000000";
    this.Sc = "#ffffff";
    this.Kc = n;
    this.Mc = "#000000";
    this.Oc = "#fff000";
    this.Lc = n;
    this.Nc = this.Tc = this.Rc = 1;
    this.Pc = 1.2;
    this.Z = b;
    this.e = a;
    this.sa = b.getContext("2d");
    this.sa.lineWidth = 1;
    this.cc = n
};
q.Yb = function() {
    var a = this,
        b = this.Z;
    this.ec = N(this.Z, hf, function(c) {
        c = rf(c, b);
        if (a.cc) {
            a.w = {
                x: c.x,
                y: c.y
            };
            a.sa.clearRect(0, 0, b.width, b.height);
            var c = a.w.x - a.I.x,
                d = a.w.y - a.I.y;
            a.drawShape(a.sa, {
                type: "rect",
                geometry: {
                    x: 0 < c ? a.I.x : a.w.x,
                    y: 0 < d ? a.I.y : a.w.y,
                    width: Math.abs(c),
                    height: Math.abs(d)
                }
            })
        }
    });
    this.fc = N(b, pf, function(c) {
        var d = rf(c, b),
            f = a.getShape(),
            c = c.n ? c.n : c;
        a.cc = n;
        f ? (a.xb(), a.e.fireEvent("onSelectionCompleted", {
            mouseEvent: c,
            shape: f,
            viewportBounds: a.getViewportBounds()
        })) : (a.e.fireEvent("onSelectionCanceled"),
            c = a.e.nb(d.x, d.y), 0 < c.length && a.e.o(c[0]))
    })
};
q.xb = function() {
    this.ec && (O(this.ec), delete this.ec);
    this.fc && (O(this.fc), delete this.fc)
};
q.getName = ba("rect_drag");
q.getSupportedShapeType = ba("rect");
q.ga = function(a) {
    a.hasOwnProperty("outline") && (this.Qc = a.outline);
    a.hasOwnProperty("stroke") && (this.Sc = a.stroke);
    a.hasOwnProperty("fill") && (this.Kc = a.fill);
    a.hasOwnProperty("hi_outline") && (this.Mc = a.hi_outline);
    a.hasOwnProperty("hi_stroke") && (this.Oc = a.hi_stroke);
    a.hasOwnProperty("hi_fill") && (this.Lc = a.hi_fill);
    a.hasOwnProperty("outline_width") && (this.Rc = a.outline_width);
    a.hasOwnProperty("stroke_width") && (this.Tc = a.stroke_width);
    a.hasOwnProperty("hi_outline_width") && (this.Nc = a.hi_outline_width);
    a.hasOwnProperty("hi_stroke_width") &&
        (this.Pc = a.hi_stroke_width)
};
q.startSelection = function(a, b) {
    var c = {
        x: a,
        y: b
    };
    this.cc = j;
    this.Yb(c);
    this.I = new W(a, b);
    this.e.fireEvent("onSelectionStarted", {
        offsetX: a,
        offsetY: b
    });
    Q(document.body, "-webkit-user-select", "none")
};
q.stopSelection = function() {
    this.xb();
    this.sa.clearRect(0, 0, this.Z.width, this.Z.height);
    Q(document.body, "-webkit-user-select", "auto");
    delete this.w
};
q.getShape = function() {
    if (this.w && 3 < Math.abs(this.w.x - this.I.x) && 3 < Math.abs(this.w.y - this.I.y)) {
        var a = this.getViewportBounds(),
            a = this.e.Wb({
                x: a.left,
                y: a.top,
                width: a.right - a.left,
                height: a.bottom - a.top
            });
        return new zd("rect", a)
    }
};
q.getViewportBounds = function() {
    var a, b;
    this.w.x > this.I.x ? (a = this.w.x, b = this.I.x) : (a = this.I.x, b = this.w.x);
    var c, d;
    this.w.y > this.I.y ? (c = this.I.y, d = this.w.y) : (c = this.w.y, d = this.I.y);
    return {
        top: c,
        right: a,
        bottom: d,
        left: b
    }
};
q.drawShape = function(a, b, c) {
    var d, f, e, h;
    "rect" == b.type && ("style" in b ? c ? (d = b.style.hi_fill, c = b.style.hi_stroke, f = b.style.hi_outline, e = b.style.xe, h = b.style.ye) : (d = b.style.fill, c = b.style.stroke, f = b.style.outline, e = b.style.Ce, h = b.style.Ee) : c ? (d = this.Lc, c = this.Oc, f = this.Mc, e = this.Nc, h = this.Pc) : (d = this.Kc, c = this.Sc, f = this.Qc, e = this.Rc, h = this.Tc), b = b.geometry, f && (a.lineJoin = "round", a.lineWidth = e, a.strokeStyle = f, a.strokeRect(b.x + e / 2, b.y + e / 2, b.width - e, b.height - e)), c && (a.lineJoin = "miter", a.lineWidth = h, a.strokeStyle =
        c, a.strokeRect(b.x + e + h / 2, b.y + e + h / 2, b.width - 2 * e - h, b.height - 2 * e - h)), d && (a.lineJoin = "miter", a.lineWidth = h, a.fillStyle = d, a.fillRect(b.x + e + h / 2, b.y + e + h / 2, b.width - 2 * e - h, b.height - 2 * e - h)))
};

function tf(a) {
    return '<canvas class="annotorious-item annotorious-opacity-fade" style="position:absolute; top:0px; left:0px; width:' + Ue(a.width) + "px; height:" + Ue(a.height) + 'px; z-index:0" width="' + Ue(a.width) + '" height="' + Ue(a.height) + '"></canvas>'
}

function bf(a) {
    return '<div class="annotorious-hint" style="white-space:nowrap; position:absolute; top:0px; left:0px; pointer-events:none;"><div class="annotorious-hint-msg annotorious-opacity-fade">' + Ue(a.Mb) + '</div><div class="annotorious-hint-icon" style="pointer-events:auto"></div></div>'
};

function uf(a, b) {
    function c(b, c) {
        Q(d, "margin-" + b, c + "px");
        Q(a, "margin-" + b, 0);
        Q(a, "padding-" + b, 0)
    }
    this.$ = a;
    this.bd = {
        padding: a.style.padding,
        margin: a.style.margin
    };
    this.t = new rd;
    this.Ia = [];
    this.ic = j;
    this.element = wb("div", "annotorious-annotationlayer");
    Q(this.element, "position", "relative");
    Q(this.element, "display", "inline-block");
    var d = this.element,
        f = dd(a, "margin"),
        e = dd(a, "padding");
    (0 != f.top || 0 != e.top) && c("top", f.top + e.top);
    (0 != f.right || 0 != e.right) && c("right", f.right + e.right);
    (0 != f.bottom || 0 != e.bottom) &&
    c("bottom", f.bottom + e.bottom);
    (0 != f.left || 0 != e.left) && c("left", f.left + e.left);
    (f = a.parentNode) && f.replaceChild(this.element, a);
    this.element.appendChild(a);
    f = $c(a);
    this.ia = Od(tf, {
        width: f.width,
        height: f.height
    });
    ef && jb(this.ia, "annotorious-item-unfocus");
    this.element.appendChild(this.ia);
    this.c = Od(tf, {
        width: f.width,
        height: f.height
    });
    ef && U(this.c, n);
    this.element.appendChild(this.c);
    this.popup = b ? b : new df(this);
    f = new sf;
    f.init(this, this.c);
    this.Ia.push(f);
    this.Ga = f;
    this.editor = new $e(this);
    this.k = new gf(this.ia,
        this);
    this.ab = new af(this, this.element);
    var h = this;
    ef && (N(this.element, of, function(a) {
        a = a.relatedTarget;
        if (!a || !Bb(h.element, a)) h.t.fireEvent("onMouseOverItem"), nb(h.ia, "annotorious-item-unfocus", "annotorious-item-focus")
    }), N(this.element, qf, function(a) {
        a = a.relatedTarget;
        if (!a || !Bb(h.element, a)) h.t.fireEvent("onMouseOutOfItem"), nb(h.ia, "annotorious-item-focus", "annotorious-item-unfocus")
    }));
    var k = mf ? this.c : this.ia;
    N(k, nf, function(a) {
        a = rf(a, k);
        h.k.o(n);
        h.ic ? (U(h.c, j), h.Ga.startSelection(a.x, a.y)) :
            (a = h.k.nb(a.x, a.y), 0 < a.length && h.k.o(a[0]))
    });
    this.t.addHandler("onSelectionCompleted", function(a) {
        var b = a.viewportBounds;
        h.editor.setPosition(new W(b.left + h.$.offsetLeft, b.bottom + 4 + h.$.offsetTop));
        h.editor.open(n, a)
    });
    this.t.addHandler("onSelectionCanceled", function() {
        ef && U(h.c, n);
        h.Ga.stopSelection()
    })
}
v(uf, ff);
q = uf.prototype;
q.ba = p();
q.ed = function(a) {
    a.init(this, this.c);
    this.Ia.push(a)
};
q.destroy = function() {
    var a = this.$;
    a.style.margin = this.bd.margin;
    a.style.padding = this.bd.padding;
    var b = this.element,
        c = b.parentNode;
    c && c.replaceChild(a, b)
};
q.pc = function(a) {
    this.k.v(a);
    var b = Ea(this.Ia, function(b) {
        return b.getSupportedShapeType() == a.shapes[0].type
    });
    if (b) {
        U(this.c, j);
        this.k.o(n);
        var c = this.c.getContext("2d"),
            d = a.shapes[0],
            f = this,
            d = "pixel" == d.units ? d : Dd(d, function(a) {
                return f.wa(a)
            });
        b.drawShape(c, d)
    }
    b = Bd(a.shapes[0]).geometry;
    b = "pixel" == a.shapes[0].units ? new W(b.x, b.y + b.height) : this.wa(new W(b.x, b.y + b.height));
    this.editor.setPosition(new W(b.x + this.$.offsetLeft, b.y + 4 + this.$.offsetTop));
    this.editor.open(a)
};
q.wa = function(a) {
    var b = Yc(this.$);
    return a.width ? {
        x: a.x * b.width,
        y: a.y * b.height,
        width: a.width * b.width,
        height: a.height * b.height
    } : {
        x: a.x * b.width,
        y: a.y * b.height
    }
};
q.xa = aa("Ga");
q.B = function() {
    return this.k.B()
};
q.nb = function(a, b) {
    return Ga(this.k.nb(a, b))
};
q.ka = aa("Ia");
q.getItem = function() {
    return {
        src: vf(this.$),
        element: this.$
    }
};

function vf(a) {
    var b = a.getAttribute("data-original");
    return b ? b : a.src
}
q.ea = function() {
    U(this.ia, n)
};
q.M = function() {
    this.ic = n;
    this.ab && (this.ab.destroy(), delete this.ab)
};
q.Kd = function(a) {
    (this.Ga = Ea(this.Ia, function(b) {
        return b.getName() == a
    })) || console.log('WARNING: selector "' + a + '" not available')
};
q.ga = function(a) {
    B(this.Ia, function(b) {
        b.ga(a)
    });
    kf(this.k)
};
q.Ca = function() {
    U(this.ia, j)
};
q.Y = function() {
    this.ic = j;
    this.ab || (this.ab = new af(this, this.element))
};
q.stopSelection = function(a) {
    ef && U(this.c, n);
    this.Ga.stopSelection();
    a && this.k.G(a)
};
q.Wb = function(a) {
    var b = Yc(this.$);
    return a.width ? {
        x: a.x / b.width,
        y: a.y / b.height,
        width: a.width / b.width,
        height: a.height / b.height
    } : {
        x: a.x / b.width,
        y: a.y / b.height
    }
};
uf.prototype.addSelector = uf.prototype.ed;
uf.prototype.fireEvent = uf.prototype.fireEvent;
uf.prototype.setCurrentSelector = uf.prototype.Kd;
uf.prototype.toItemCoordinates = uf.prototype.Wb;

function wf() {
    Hd(this, function() {
        return K("img.annotatable", document)
    })
}
v(wf, Gd);
wf.prototype.Fb = function(a) {
    return vf(a)
};
wf.prototype.zc = function(a) {
    return new uf(a)
};
wf.prototype.Vb = function(a) {
    return Ab(a) ? "IMG" == a.tagName : n 
	console.log("a.tagName "+a.tagName);
};

function xf(a) {
    return '<div class="annotorious-opacity-fade" style="white-space:nowrap; position:absolute; pointer-events:none; top:80px; width:100%; text-align:center;"><div class="annotorious-ol-hint" style="width: 400px; margin:0px auto;">' + Ue(a.Mb) + "</dvi></div>"
};

function yf(a, b) {
    this.V = a;
    this.R = $c(b.element);
    this.j = b.popup;
    Q(this.j.element, "z-index", 99E3);
    this.S = [];
    this.ub = new OpenLayers.Layer.Boxes("Annotorious");
    this.V.addLayer(this.ub);
    var c = this;
    this.V.events.register("move", this.V, function() {
        c.F && c.bb()
    });
    b.addHandler("beforePopupHide", function() {
        c.ta == c.F ? c.j.clearHideTimer() : c.gb(c.ta, c.F)
    })
}
q = yf.prototype;
q.destroy = function() {
    this.ub.destroy()
};
q.bb = function() {
    var a = this.F.Lb.div,
        b = $c(a),
        c = Uc(a, this.V.div),
        a = c.y,
        c = c.x,
        d = b.width,
        f = b.height,
        b = $c(this.j.element),
        a = {
            y: a + f + 5
        };
    c + b.width > this.R.width ? (nb(this.j.element, "top-left", "top-right"), a.x = c + d - b.width) : (nb(this.j.element, "top-right", "top-left"), a.x = c);
    0 > a.x && (a.x = 0);
    a.x + b.width > this.R.width && (a.x = this.R.width - b.width);
    a.y + b.height > this.R.height && (a.y = this.R.height - b.height);
    this.j.setPosition(a)
};
q.jc = function(a) {
    this.j.setAnnotation(a);
    this.bb();
    this.j.show()
};
q.gb = function(a, b) {
    a ? (Uc(a.Lb.div, this.V.div), za("height"), Q(a.rb, "border-color", "#fff000"), this.F = a, this.jc(a.K)) : delete this.F;
    b && Q(b.rb, "border-color", "#fff")
};
q.G = function(a) {
    var b = a.shapes[0].geometry,
        b = new OpenLayers.Marker.Box(new OpenLayers.Bounds(b.x, b.y, b.x + b.width, b.y + b.height));
    jb(b.div, "annotorious-ol-boxmarker-outer");
    Q(b.div, "border", m);
    var c = wb("div", "annotorious-ol-boxmarker-inner");
    Xc(c, "100%", "100%");
    b.div.appendChild(c);
    var d = {
            K: a,
            Lb: b,
            rb: c
        },
        f = this;
    N(c, "mouseover", function() {
        f.F || f.gb(d);
        f.ta = d
    });
    N(c, "mouseout", function() {
        delete f.ta;
        f.j.startHideTimer()
    });
    this.S.push(d);
    z.sort.call(this.S, function(a, b) {
            return Ad(b.K.shapes[0]) - Ad(a.K.shapes[0])
        } ||
        Ja);
    var e = 1E4;
    B(this.S, function(a) {
        Q(a.Lb.div, "z-index", e);
        e++
    });
    this.ub.addMarker(b)
};
q.v = function(a) {
    var b = Ea(this.S, function(b) {
        return b.K == a
    });
    b && (C(this.S, b), this.ub.removeMarker(b.Lb))
};
q.B = p();
q.o = function(a) {
    a || this.j.startHideTimer()
};

function zf(a) {
    function b() {
        var a = parseInt(R(d.element, "width"), 10),
            b = parseInt(R(d.element, "height"), 10);
        Xc(d.c, a, b);
        d.c.width = a;
        d.c.height = b
    }
    this.V = a;
    this.element = a.div;
    var c = this.element.style[za("position")] || "";
    "absolute" != c && "relative" != c && Q(this.element, "position", "relative");
    this.t = new rd;
    this.J = Od(xf, {
        Mb: "Click and Drag"
    });
    Q(this.J, "z-index", 9998);
    T(this.J, 0);
    this.element.appendChild(this.J);
    this.popup = new df(this);
    this.k = new yf(a, this);
    this.c = Od(tf, {
        width: "0",
        height: "0"
    });
    U(this.c, n);
    Q(this.c,
        "position", "absolute");
    Q(this.c, "top", "0px");
    Q(this.c, "z-index", 9999);
    this.element.appendChild(this.c);
    var d = this;
    b();
    this.T = new sf;
    this.T.init(this, this.c);
    this.fb = i;
    this.editor = new $e(this);
    Q(this.editor.element, "z-index", 1E4);
    window.addEventListener ? window.addEventListener("resize", b, n) : window.attachEvent && window.attachEvent("onresize", b);
    N(this.element, "mouseover", function(a) {
        a = a.relatedTarget;
        (!a || !Bb(d.element, a)) && d.t.fireEvent("onMouseOverItem")
    });
    N(this.element, "mouseout", function(a) {
        a = a.relatedTarget;
        (!a || !Bb(d.element, a)) && d.t.fireEvent("onMouseOutOfItem")
    });
    N(this.c, "mousedown", function(a) {
        var b = Vc(d.element);
        d.T.startSelection(a.clientX - b.x, a.clientY - b.y)
    });
    this.t.addHandler("onSelectionCompleted", function(a) {
        Q(d.c, "pointer-events", "none");
        a = a.viewportBounds;
        d.editor.setPosition(new W(a.left, a.bottom + 4));
        d.editor.open()
    });
    this.t.addHandler("onSelectionCanceled", function() {
        d.stopSelection()
    })
}
v(zf, ff);
q = zf.prototype;
q.Y = p();
q.M = p();
q.ba = function(a) {
    Q(this.c, "pointer-events", "auto");
    var b = this;
    U(this.c, j);
    T(this.J, 0.8);
    window.setTimeout(function() {
        T(b.J, 0)
    }, 2E3);
    a && (this.fb = a)
};
q.destroy = function() {
    this.k.destroy();
    zb(this.J);
    zb(this.c)
};
q.ed = p();
q.pc = function(a) {
    this.k.v(a);
    var b = this.T,
        c = this;
    if (b) {
        U(this.c, j);
        this.k.o(i);
        var d = this.c.getContext("2d"),
            f = Dd(a.shapes[0], function(a) {
                return c.wa(a)
            });
        console.log(f);
        b.drawShape(d, f);
        b = Bd(f).geometry;
        this.editor.setPosition(new W(b.x, b.y + b.height));
        this.editor.open(a)
    }
};
q.wa = function(a) {
    var b = this.V.getViewPortPxFromLonLat(new OpenLayers.LonLat(a.x, a.y));
    return (a = a.width ? this.V.getViewPortPxFromLonLat(new OpenLayers.LonLat(a.x + a.width, a.y + a.height)) : n) ? {
        x: b.x,
        y: a.y,
        width: a.x - b.x + 2,
        height: b.y - a.y + 2
    } : {
        x: b.x,
        y: b.y
    }
};
q.B = p();
q.ka = p();
q.getItem = function() {
    return {
        src: "map://openlayers/something"
    }
};
q.tb = p();
q.Wb = function(a) {
    var b = this.V.getLonLatFromPixel(new OpenLayers.Pixel(a.x, a.y));
    return (a = a.width ? new OpenLayers.Pixel(a.x + a.width - 2, a.y + a.height - 2) : n) ? (a = this.V.getLonLatFromPixel(a), b = {
        x: b.lon,
        y: a.lat,
        width: a.lon - b.lon,
        height: b.lat - a.lat
    }, console.log(b), b) : {
        x: b.lon,
        y: b.lat
    }
};

function Af() {
    Hd(this)
}
v(Af, Gd);
Af.prototype.Fb = ba("map://openlayers/something");
Af.prototype.zc = function(a) {
    return new zf(a)
};
Af.prototype.Vb = function(a) {
    return a instanceof OpenLayers.Map
};

function Bf(a, b) {
    this.W = a;
    this.R = $c(a.element);
    this.j = b.popup;
    Q(this.j.element, "z-index", 99E3);
    this.S = [];
    var c = this;
    this.W.addHandler("animation", function() {
        c.F && c.bb()
    });
    b.addHandler("beforePopupHide", function() {
        c.ta == c.F ? c.j.clearHideTimer() : c.gb(c.ta, c.F)
    })
}
q = Bf.prototype;
q.bb = function() {
    var a = this.W.element,
        b = this.F.Ac,
        c = $c(b),
        b = Uc(b, a),
        a = b.y,
        b = b.x,
        d = c.width,
        f = c.height,
        c = $c(this.j.element),
        a = {
            x: b,
            y: a + f + 12
        };
    nb(this.j.element, "top-right", "top-left");
    this.W.isFullPage() || (b + c.width > this.R.width && (nb(this.j.element, "top-left", "top-right"), a.x = b + d - c.width), 0 > a.x && (a.x = 0), a.x + c.width > this.R.width && (a.x = this.R.width - c.width), a.y + c.height > this.R.height && (a.y = this.R.height - c.height));
    this.j.setPosition(a)
};
q.jc = function(a) {
    this.j.setAnnotation(a);
    this.bb();
    this.j.show()
};
q.gb = function(a, b) {
    a ? (Q(a.rb, "border-color", "#fff000"), this.F = a, this.jc(a.K)) : delete this.F;
    b && Q(b.rb, "border-color", "#fff")
};
q.G = function(a) {
    var b = a.shapes[0].geometry,
        c = wb("div", "annotorious-ol-boxmarker-outer"),
        d = wb("div", "annotorious-ol-boxmarker-inner");
    Xc(d, "100%", "100%");
    c.appendChild(d);
    var b = new OpenSeadragon.Rect(b.x, b.y, b.width, b.height),
        f = {
            K: a,
            Ac: c,
            rb: d
        },
        e = this;
    N(d, "mouseover", function() {
        e.F || e.gb(f);
        e.ta = f
    });
    N(d, "mouseout", function() {
        delete e.ta;
        e.j.startHideTimer()
    });
    this.S.push(f);
    z.sort.call(this.S, function(a, b) {
        return Ad(b.K.shapes[0]) - Ad(a.K.shapes[0])
    } || Ja);
    var h = 1E4;
    B(this.S, function(a) {
        Q(a.Ac, "z-index",
            h);
        h++
    });
    this.W.drawer.addOverlay(c, b)
};
q.v = function(a) {
    var b = Ea(this.S, function(b) {
        return b.K == a
    });
    b && (C(this.S, b), this.W.drawer.removeOverlay(b.Ac))
};
q.B = p();
q.o = p();

function Cf(a) {
    this.element = a.element;
    this.W = a;
    this.t = new rd;
    this.J = Od(xf, {
        Mb: "Click and Drag"
    });
    Q(this.J, "z-index", 9998);
    T(this.J, 0);
    this.element.appendChild(this.J);
    this.popup = new df(this);
    this.k = new Bf(a, this);
    this.c = Od(tf, {
        width: "0",
        height: "0"
    });
    U(this.c, n);
    Q(this.c, "position", "absolute");
    Q(this.c, "top", "0px");
    Q(this.c, "z-index", 9999);
    this.element.appendChild(this.c);
    var b = this;
    this.T = new sf;
    this.T.init(this, this.c);
    var a = parseInt(R(b.element, "width"), 10),
        c = parseInt(R(b.element, "height"), 10);
    Xc(b.c, a, c);
    b.c.width = a;
    b.c.height = c;
    this.T = new sf;
    this.T.init(this, this.c);
    this.editor = new $e(this);
    N(this.c, "mousedown", function(a) {
        var c = Vc(b.element);
        b.T.startSelection(a.clientX - c.x, a.clientY - c.y)
    });
    this.t.addHandler("onSelectionCompleted", function(a) {
        Q(b.c, "pointer-events", "none");
        a = a.viewportBounds;
        b.editor.setPosition(new W(a.left, a.bottom + 4));
        b.editor.open()
    });
    this.t.addHandler("onSelectionCanceled", function() {
        b.stopSelection()
    })
}
v(Cf, ff);
q = Cf.prototype;
q.Y = p();
q.M = p();
q.ba = function(a) {
    Q(this.c, "pointer-events", "auto");
    var b = this;
    U(this.c, j);
    T(this.J, 0.8);
    window.setTimeout(function() {
        T(b.J, 0)
    }, 2E3);
    a && (this.fb = a)
};
q.pc = function(a) {
    this.k.v(a);
    var b = this.T,
        c = this;
    if (b) {
        U(this.c, j);
        this.k.o(i);
        var d = this.c.getContext("2d"),
            f = Dd(a.shapes[0], function(a) {
                return c.wa(a)
            });
        b.drawShape(d, f);
        b = Bd(f).geometry;
        this.editor.setPosition(new W(b.x, b.y + b.height + 4));
        this.editor.open(a)
    }
};
q.wa = function(a) {
    var b = qd(this.element);
    b.top += window.pageYOffset;
    b.left += window.pageXOffset;
    var c = new OpenSeadragon.Point(a.x, a.y),
        a = a.width ? new OpenSeadragon.Point(a.x + a.width, a.y + a.height) : n,
        c = this.W.viewport.viewportToWindowCoordinates(c);
    return a ? (a = this.W.viewport.viewportToWindowCoordinates(a), {
        x: c.x - b.left,
        y: c.y - b.top,
        width: a.x - c.x + 2,
        height: a.y - c.y + 2
    }) : c
};
q.B = p();
q.ka = p();
q.getItem = function() {
    return {
        src: "dzi://openseadragon/something"
    }
};
q.tb = p();
q.Wb = function(a) {
    var b = qd(this.element);
    b.top += window.pageYOffset;
    b.left += window.pageXOffset;
    var c = new OpenSeadragon.Point(a.x + b.left, a.y + b.top),
        a = a.width ? new OpenSeadragon.Point(a.x + b.left + a.width - 2, a.y + b.top + a.height - 2) : n,
        c = this.W.viewport.windowToViewportCoordinates(c);
    return a ? (a = this.W.viewport.windowToViewportCoordinates(a), {
        x: c.x,
        y: c.y,
        width: a.x - c.x,
        height: a.y - c.y
    }) : c
};

function Df() {
    Hd(this)
}
v(Df, Gd);
Df.prototype.Fb = ba("dzi://openseadragon/something");
Df.prototype.zc = function(a) {
    return new Cf(a)
};
Df.prototype.Vb = function(a) {
    return !a.id || 0 != a.id.indexOf("openseadragon") || !a.hasOwnProperty("drawer") ? n : j
};

function Y() {
    function a() {
        Ef(b)
    }
    this.Xc = n;
    this.l = [new wf];
    window.OpenLayers && this.l.push(new Af);
    window.OpenSeadragon && this.l.push(new Df);
    this.cb = [];
    var b = this;
    window.addEventListener ? window.addEventListener("load", a, n) : window.attachEvent && window.attachEvent("onload", a)
}

function Ef(a) {
    a.Xc || (B(a.l, function(a) {
        a.init()
    }), B(a.cb, function(b) {
        b.initPlugin && b.initPlugin(a);
        B(a.l, function(a) {
            a.zb(b)
        })
    }), a.Xc = j)
}

function Z(a, b) {
    return Ea(a.l, function(a) {
        return Nd(a, b)
    })
}
q = Y.prototype;
q.ba = function(a, b) {
    var c = i,
        d = i;
    t(a) ? (c = a, d = b) : u(a) && (d = a);
    if (c) {
        var f = Z(this, c);
        f && f.ba(c, d)
    } else B(this.l, function(a) {
        a.ba(d)
    })
};
q.G = function(a, b) {
    var c;
    c = a.src;
    if (!(0 < c.indexOf("://"))) {
        var d = document.createElement("a");
        d.href = c;
        c = d.protocol + "//" + d.host + d.pathname
    }
    a.src = c;
    (c = Z(this, a.src)) && c.G(a, b)
};
q.addHandler = function(a, b) {
    B(this.l, function(c) {
        c.addHandler(a, b)
    })
};
q.zb = function(a, b) {
    try {
        var c = new window.annotorious.plugin[a](b);
        "complete" == document.readyState ? (c.initPlugin && c.initPlugin(this), B(this.l, function(a) {
            a.zb(c)
        })) : this.cb.push(c)
    } catch (d) {
        console.log("Could not load plugin: " + a)
    }
};
q.destroy = function(a) {
    if (a) {
        var b = Z(this, a);
        b && b.destroy(a)
    } else B(this.l, function(a) {
        a.destroy()
    })
};
q.xa = function(a) {
    var b = Z(this, a);
    if (b) return b.xa(a)
};
q.B = function(a) {
    if (a) {
        var b = Z(this, a);
        return b ? b.B(a) : []
    }
    var c = [];
    B(this.l, function(a) {
        Ha(c, a.B())
    });
    return c
};
q.ka = function(a) {
    var b = Z(this, a);
    return b ? b.ka(a) : []
};
q.ea = function(a) {
    if (a) {
        var b = Z(this, a);
        b && b.ea(a)
    } else B(this.l, function(a) {
        a.ea()
    })
};
q.M = function(a) {
    if (a) {
        var b = Z(this, a);
        b && b.M(a)
    } else B(this.l, function(a) {
        a.M()
    })
};
q.o = function(a) {
    if (a) {
        var b = Z(this, a.src);
        b && b.o(a)
    } else B(this.l, function(a) {
        a.o()
    })
};
q.xc = function(a) {
    Ef(this);
    var b = Ea(this.l, function(b) {
        return b.Vb(a)
    });
    b ? b.xc(a) : g("Error: Annotorious does not support this media type in the current version or build configuration.")
};
q.Rb = function(a) {
    var b = this;
    B(this.B(a), function(a) {
        b.v(a)
    })
};
q.v = function(a) {
    var b = Z(this, a.src);
    b && b.v(a)
};
q.reset = function() {
    B(this.l, function(a) {
        a.destroy();
        a.init()
    })
};
q.tb = function(a, b) {
    var c = Z(this, a);
    c && c.tb(a, b)
};
q.ga = function(a) {
    B(this.l, function(b) {
        b.ga(a)
    })
};
q.le = function(a) {
    a ? this.Y(i) : this.M(i)
};
q.Ca = function(a) {
    if (a) {
        var b = Z(this, a);
        b && b.Ca(a)
    } else B(this.l, function(a) {
        a.Ca()
    })
};
q.Y = function(a) {
    if (a) {
        var b = Z(this, a);
        b && b.Y(a)
    } else B(this.l, function(a) {
        a.Y()
    })
};
window.anno = new Y;
Y.prototype.activateSelector = Y.prototype.ba;
Y.prototype.addAnnotation = Y.prototype.G;
Y.prototype.addHandler = Y.prototype.addHandler;
Y.prototype.addPlugin = Y.prototype.zb;
Y.prototype.destroy = Y.prototype.destroy;
Y.prototype.getActiveSelector = Y.prototype.xa;
Y.prototype.getAnnotations = Y.prototype.B;
Y.prototype.getAvailableSelectors = Y.prototype.ka;
Y.prototype.hideAnnotations = Y.prototype.ea;
Y.prototype.hideSelectionWidget = Y.prototype.M;
Y.prototype.highlightAnnotation = Y.prototype.o;
Y.prototype.makeAnnotatable = Y.prototype.xc;
Y.prototype.removeAll = Y.prototype.Rb;
Y.prototype.removeAnnotation = Y.prototype.v;
Y.prototype.reset = Y.prototype.reset;
Y.prototype.setActiveSelector = Y.prototype.tb;
Y.prototype.setProperties = Y.prototype.ga;
Y.prototype.showAnnotations = Y.prototype.Ca;
Y.prototype.showSelectionWidget = Y.prototype.Y;
window.annotorious || (window.annotorious = {});
window.annotorious.plugin || (window.annotorious.plugin = {});
window.annotorious.geometry || (window.annotorious.geometry = {}, window.annotorious.geometry.expand = Cd, window.annotorious.geometry.getBoundingRect = Bd);
Y.prototype.setSelectionEnabled = Y.prototype.le;
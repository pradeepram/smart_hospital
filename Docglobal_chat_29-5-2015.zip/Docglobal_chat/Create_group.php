<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
	$grp_name = (string) $_GET["group_name"];    
	$userid = (string) $_GET["userid"];
     $grp_image = (string) $_GET["group_image"];    
			
		
$my_values = array();
             
	

	$select = mysql_query("select Id from m_group where CreatedBy='$userid' and group_name='$grp_name' and DATE(CreatedTime)=DATE(NOW())"); 
		$output = mysql_num_rows(@$select);
		if ($output=="0")
		{	

		 $add = mysql_query("INSERT INTO m_group(group_name,image,CreatedBy,CreatedTime) VALUES('$grp_name','$grp_image','$userid',NOW())");
		}
		
		$result = mysql_query("select Id from m_group where group_name='$grp_name' and CreatedBy='$userid'");
while($rows = mysql_fetch_array($result))
{
    $return1= "{$rows['Id']}" ;
           
  $my_values[] = $return1;  
                                                                    
}
		
	
	 echo json_encode(array("group_id"=>$my_values));
		
?>
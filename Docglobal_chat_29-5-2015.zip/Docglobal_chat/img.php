<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();
            


 $add = mysql_query("SELECT img_id,image,user_id FROM `m_image` WHERE 1");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['img_id']}" ;
     $return2= "{$row['image']}" ;    
	  $return3= "{$row['user_id']}" ; 
  $my_values[] = $return1;  
   $my_values1[] = $return2;      
 $my_values2[] = $return3;    
}




  echo json_encode(array("imgid"=>$my_values,"image"=>$my_values1,"userid"=>$my_values2));
?>


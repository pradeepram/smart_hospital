<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
			header("Content-type: text/plain");
$username = (string) $_GET["username"];
$pwd  = (string) $_GET["pwd"];
	
		
$my_values = array();
$my_values1 = array();

		
		$retrieve = mysql_query("select user_id,firstname from m_user
								 WHERE BINARY username='$username' AND BINARY password='$pwd' ");
		
		while($rows = mysql_fetch_array($retrieve))
{
    $return1= "{$rows['user_id']}" ;
    $return2= "{$rows['firstname']}" ;
   $my_values[] = $return1;  
   $my_values1[] = $return2;  
    
}
		$insert = mysql_query("insert into m_online(user_id,status,createdTime) values('$return1',1,NOW()) ");
	
	
		echo json_encode(array("user_id"=>$my_values,"firstname"=>$my_values1));
		
?>
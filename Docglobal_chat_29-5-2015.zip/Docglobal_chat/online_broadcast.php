<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();
$my_values5 = array();
            


 $add = mysql_query("select c.*, d.broadcast_name
from
(
select b.b_id as Id,b.image from m_broadcast b
where b.b_id in (SELECT b_id FROM m_broadcast_members where user_id='$userid')
) as c
left join
(
select b.b_id as Id,count(*) as broadcast_name from m_broadcast b
where b.b_id in (SELECT b_id FROM m_broadcast_members where user_id='$userid')
) as d on (d.Id = c.Id)");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['Id']}" ;
     $return2= "{$row['broadcast_name']}" ;      
          $return5= "{$row['image']}" ;    
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
                           $my_values5[] = $return5;                                      
}




  echo json_encode(array("b_id"=>$my_values,"broadcast_name"=>$my_values1,"image"=>$my_values5));
?>


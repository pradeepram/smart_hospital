$.emojiarea.path = '../packs/basic';
$.emojiarea.icons = {
	':smile:'     : 'smile.png',
	':angry:'     : 'angry.png',
	':flushed:'   : 'flushed.png',
	':neckbeard:' : 'neckbeard.png',
	':laughing:'  : 'laughing.png'
};
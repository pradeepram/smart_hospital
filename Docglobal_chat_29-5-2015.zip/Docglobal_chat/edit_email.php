<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		$email = (string) $_GET["email"];
		
		
$my_values = array();
            
 $add = mysql_query("update m_user set emailaddress='$email' where user_id='$userid'");

 $sele = mysql_query("SELECT emailaddress as email FROM m_user where user_id='$userid' ");
while($row = mysql_fetch_array($sele))
{
    $return1= "{$row['email']}" ;
  $my_values[] = $return1;    
}
  echo json_encode(array("email"=>$my_values));
?>


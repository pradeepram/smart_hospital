<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		$gid = (string) $_GET["gid"];
		
$my_values = array();
$my_values1 = array();
$my_values2 = array();
$my_values3 = array();
$my_values4 = array();


 $add = mysql_query("select g.group_name,u.firstname,date_format(g.CreatedTime, '%Y-%m-%d') as time,g.image from m_group g
left join m_user u on (u.user_id=g.CreatedBy)
where g.Id='$gid'");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['group_name']}" ;
    $return2= "{$row['firstname']}" ;
	$return3= "{$row['time']}" ;
	$return4= "{$row['image']}" ;
	
  $my_values[] = $return1;  
  $my_values1[] = $return2;  
$my_values2[] = $return3;  
$my_values3[] = $return4;    
   
}



  echo json_encode(array("name"=>$my_values,"firstname"=>$my_values1,"time"=>$my_values2,"image"=>$my_values3));
?>


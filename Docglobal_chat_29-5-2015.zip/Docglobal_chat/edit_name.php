<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		$name = (string) $_GET["name"];
		
		
$my_values = array();
            
 $add = mysql_query("update m_user set firstname='$name' where user_id='$userid'");

 $sele = mysql_query("SELECT firstname as name FROM m_user where user_id='$userid' ");
while($row = mysql_fetch_array($sele))
{
    $return1= "{$row['name']}" ;
  $my_values[] = $return1;    
}
  echo json_encode(array("name"=>$my_values));
?>


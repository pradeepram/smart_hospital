<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
	$bid = (string) $_GET["bid"];    
	$userid = (string) $_GET["userid"];
     $broadcast_members = json_decode(stripslashes($_GET["broadcast_members"]));  
			
		
$my_values = array();
             
		foreach($broadcast_members as $d){

	$select = mysql_query("select m_b_id from m_broadcast_members where CreatedBy='$userid' and b_id='$bid' and user_id='$d' and DATE(createdTime)=DATE(NOW())"); 
		$output = mysql_num_rows(@$select);
		if ($output=="0")
		{	
 
   $test_values = mysql_query("INSERT INTO m_broadcast_members(b_id,user_id,createdBy,createdTime) VALUES('$bid','$d','$userid',NOW())");   
  }
	
		 
		}
		

		
	
	 echo json_encode();
		
?>
<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();
            


 $add = mysql_query("select firstname,phone,emailaddress from m_user where user_id='$userid'");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['firstname']}" ;
     $return2= "{$row['phone']}" ;    
	  $return3= "{$row['emailaddress']}" ; 
  $my_values[] = $return1;  
   $my_values1[] = $return2;      
 $my_values2[] = $return3;    
}




  echo json_encode(array("firstname"=>$my_values,"phone"=>$my_values1,"emailaddress"=>$my_values2));
?>


<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		$bid = (string) $_GET["bid"];
		
		

            


 $add = mysql_query("delete from m_broadcast_members where user_id='$userid' and b_id='$bid'");





  echo json_encode();
?>


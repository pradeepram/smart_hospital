<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$gid = (string) $_GET["gid"];
		
$my_values = array();
$my_values1 = array();
$my_values2 = array();



 $add = mysql_query("select g.group_name,g.image,u.firstname from m_group g
left join m_user u on (u.user_id=g.CreatedBy)
where g.Id='$gid' group by group_name");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['group_name']}" ;
    $return2= "{$row['image']}" ;
	$return3= "{$row['firstname']}" ;

  $my_values[] = $return1;  
  $my_values1[] = $return2;  
$my_values2[] = $return3;  
  
}



  echo json_encode(array("group_name"=>$my_values,"image"=>$my_values1,"firstname"=>$my_values2));
?>


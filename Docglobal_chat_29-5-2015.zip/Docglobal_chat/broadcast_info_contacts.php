<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$bid = (string) $_GET["bid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();

            


 $add = mysql_query("SELECT bm.user_id,i.image,u.firstname,s.status_message,bm.b_id FROM m_broadcast_members bm
left join m_user u on (u.user_id=bm.user_id)
left join m_image i on (i.user_id=bm.user_id)
left join m_status s on (s.user_id=bm.user_id)
where bm.b_id='$bid' and s.state=1");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['user_id']}" ;
     $return2= "{$row['firstname']}" ;      
      $return3= "{$row['image']}" ;      
	  $return4= "{$row['status_message']}" ;      
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
    $my_values2[] = $return3;    
$my_values3[] = $return4; 	
}




  echo json_encode(array("user_id"=>$my_values,"name"=>$my_values1,"image"=>$my_values2,"status"=>$my_values3));
?>


<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$bid = (string) $_GET["bid"];
		
$my_values = array();
$my_values1 = array();
$my_values2 = array();



 $add = mysql_query("SELECT count(bm.user_id) as broadcast_name,bm.user_id,u.firstname,b.image FROM `m_broadcast_members`  bm
left join m_user u on (u.user_id=bm.user_id)
left join m_broadcast b on (b.b_id=bm.b_id)
where bm.b_id=4");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['broadcast_name']}" ;
    $return2= "{$row['image']}" ;
	$return3= "{$row['firstname']}" ;

  $my_values[] = $return1;  
  $my_values1[] = $return2;  
$my_values2[] = $return3;  
  
}



  echo json_encode(array("broadcast_name"=>$my_values,"image"=>$my_values1,"firstname"=>$my_values2));
?>


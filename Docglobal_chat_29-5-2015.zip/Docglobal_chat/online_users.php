<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();
$my_values5 = array();
            


 $add = mysql_query("select user_id,name,image, message, max(m_id), time
from
(
SELECT u.user_id,u.firstname as name,i.image, c.message, c.m_id,DATE_FORMAT(c.Time,'%H:%i') as time FROM m_user u 
left join m_image i on (i.user_id=u.user_id) 
left join m_chat c on (i.user_id=c.user_id) 
where u.user_id not in ('$userid')
    ) as d
    group by user_id");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['user_id']}" ;
     $return2= "{$row['name']}" ;      
      $return5= "{$row['image']}" ;    
         $return6= "{$row['message']}" ;    
          $return7= "{$row['time']}" ;    
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
    $my_values5[] = $return5;  
     $my_values6[] = $return6;
      $my_values7[] = $return7;                                                                
}


$result = mysql_query("SELECT u.firstname,c.message FROM m_chat c left join m_user u on (u.user_id=c.user_id) order by Time asc");
while($rows = mysql_fetch_array($result))
{
    $return3= "{$rows['firstname']}" ;
     $return4= "{$rows['message']}" ;      
  $my_values2[] = $return3;  
   $my_values3[] = $return4;                                                               
}


  echo json_encode(array("user_id"=>$my_values,"name"=>$my_values1,"firstname"=>$my_values2,"message"=>$my_values3,"image"=>$my_values5,"message"=>$my_values6,"time"=>$my_values7));
?>


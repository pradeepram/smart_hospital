<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");

	   
	$userid = (string) $_GET["userid"];
     $brd_members = json_decode(stripslashes($_GET["broadcast_members"]));  
			
		
$my_values = array();



	$select = mysql_query("select b_id from m_broadcast where createdBy='$userid' and DATE(createdTime)=DATE(NOW())"); 
		$output = mysql_num_rows(@$select);
		if ($output=="0")
		{	
$test = mysql_query("INSERT INTO m_broadcast(createdBy,createdTime) VALUES('$userid',NOW())");   

           
 $add = mysql_query("select b_id from m_broadcast where createdBy='$userid' and DATE(createdTime)=DATE(NOW())");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['b_id']}" ;        
 $my_values[] = $return1;  

}
$test_val = mysql_query("INSERT INTO m_broadcast_members(b_id,user_id,createdBy,createdTime) VALUES('$return1','$userid','$userid',NOW())");   

	foreach($brd_members as $d){
   $test_values = mysql_query("INSERT INTO m_broadcast_members(b_id,user_id,createdBy,createdTime) VALUES('$return1','$d','$userid',NOW())");   
  }	
		 
		}
					
	 echo json_encode(array("broid"=>$my_values));
		
?>
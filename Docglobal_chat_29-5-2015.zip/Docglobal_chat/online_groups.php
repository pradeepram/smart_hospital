<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();
$my_values5 = array();
            


 $add = mysql_query("select Id,group_name,image from m_group where Id in (SELECT Id FROM m_group_members where user_id='$userid')");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['Id']}" ;
     $return2= "{$row['group_name']}" ;      
          $return5= "{$row['image']}" ;    
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
                           $my_values5[] = $return5;                                      
}




  echo json_encode(array("g_id"=>$my_values,"group_name"=>$my_values1,"image"=>$my_values5));
?>


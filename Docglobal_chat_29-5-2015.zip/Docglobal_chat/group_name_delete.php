<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		$gid = (string) $_GET["gid"];
		
		

            


 $add = mysql_query("delete from m_group_members where user_id='$userid' and Id='$gid'");





  echo json_encode();
?>


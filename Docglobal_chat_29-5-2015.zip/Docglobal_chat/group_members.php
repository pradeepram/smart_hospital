<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
	$grp_id = (string) $_GET["group_id"];    
	$userid = (string) $_GET["userid"];
     $grp_members = json_decode(stripslashes($_GET["group_members"]));  
			
		
$my_values = array();
             
	

	$select = mysql_query("select m_g_id from m_group_members where CreatedBy='$userid' and Id='$grp_id' and DATE(createdTime)=DATE(NOW())"); 
		$output = mysql_num_rows(@$select);
		if ($output=="0")
		{	
$test = mysql_query("INSERT INTO m_group_members(Id,user_id,createdBy,createdTime) VALUES('$grp_id','$userid','$userid',NOW())");   
	foreach($grp_members as $d){
   $test_values = mysql_query("INSERT INTO m_group_members(Id,user_id,createdBy,createdTime) VALUES('$grp_id','$d','$userid',NOW())");   
  }	
		 
		}
		

		
	
	 echo json_encode();
		
?>
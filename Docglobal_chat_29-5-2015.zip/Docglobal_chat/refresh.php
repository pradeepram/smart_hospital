<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");

	
	$userid = (string) $_GET["userid"];
     $rec_id = (string) $_GET["recipient_id"];    
	 $md5_id = (string) $_GET["md5_id"];    		
		
$my_values = array();

	
		$result = mysql_query("SELECT 
case when md5='$md5_id' then 0
else 1 end as Flag  FROM m_chat  where user_id in ('$rec_id','$userid') and recipient in ('$rec_id','$userid') ORDER BY  m_id DESC LIMIT 1");
while($rows = mysql_fetch_array($result))
{
    $return1= "{$rows['flag']}" ;       
  $my_values[] = $return1;     
}
		
	
	 echo json_encode(array("flag"=>$my_values));
		
?>
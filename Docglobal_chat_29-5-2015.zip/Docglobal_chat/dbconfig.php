<?php
$link = mysql_connect('localhost', 'root', '') or die('error');
@mysql_select_db('chat_ui',$link) or die('error');	
?>

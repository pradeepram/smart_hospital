<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$gid = (string) $_GET["gid"];
		$userid = (string) $_GET["userid"];
$grp_name = (string) $_GET["grp_name"];
            


 $add = mysql_query("update m_group set group_name='$grp_name' where Id='$gid'");





  echo json_encode();
?>


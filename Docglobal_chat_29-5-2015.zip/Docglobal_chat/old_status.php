<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
  
	$userid = (string) $_GET["userid"];
    	
		
$my_values = array();
$my_values1 = array();

		
		$result = mysql_query("select status_message,s_id from m_status where user_id='$userid'");
while($rows = mysql_fetch_array($result))
{
    $return1= "{$rows['status_message']}" ;
     $return2= "{$rows['s_id']}" ;  
          
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
                                                                       
}
		
	
	 echo json_encode(array("status_message"=>$my_values,"s_id"=>$my_values1));
		
?>
<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
		
		header("Content-type: text/plain");
	
		$userid = (string) $_GET["userid"];
		
$my_values = array();
$my_values1 = array();
		
$my_values2 = array();
$my_values3 = array();
            


 $add = mysql_query("SELECT user_id,firstname as name FROM m_user where user_id not in ('$userid')");
while($row = mysql_fetch_array($add))
{
    $return1= "{$row['user_id']}" ;
     $return2= "{$row['name']}" ;      
  $my_values[] = $return1;  
   $my_values1[] = $return2;                                                               
}


$result = mysql_query("SELECT u.firstname,c.message FROM m_chat c left join m_user u on (u.user_id=c.user_id) order by Time asc");
while($rows = mysql_fetch_array($result))
{
    $return3= "{$rows['firstname']}" ;
     $return4= "{$rows['message']}" ;      
  $my_values2[] = $return3;  
   $my_values3[] = $return4;                                                               
}


  echo json_encode(array("user_id"=>$my_values,"name"=>$my_values1,"firstname"=>$my_values2,"message"=>$my_values3));
?>


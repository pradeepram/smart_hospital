<?php
header('Access-Control-Allow-Origin: *');
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
	ini_set('display_errors',0);
	include('dbconfig.php');
	header("Content-type: text/plain");


  
 
	$message = (string) $_GET["msg"];    
	$userid = (string) $_GET["userid"];
     $bid = (string) $_GET["bid"];    
			
		
$my_values = array();
$my_values1 = array();
 $my_values2 = array();               
 $my_values3 = array();   	
	$current_msg_digest = md5($message);
	$select = mysql_query("select m_id from m_chat where user_id='$userid' and message='$message' and DATE(Time)=DATE(NOW())"); 
		$output = mysql_num_rows(@$select);
		if ($output=="0")
		{	
	$update = mysql_query("update m_chat set md5=NULL where user_id='$userid' and b_id='$g_id' ORDER BY  m_id DESC LIMIT 1");
		 $add = mysql_query("INSERT INTO m_chat(user_id,b_id,message,Time,md5) VALUES('$userid','$bid','$message',NOW(),'$current_msg_digest')");
		}
		$current_msg_digest = md5($message);
		$result = mysql_query("SELECT u.firstname,c.message,c.image,
case when date_format(c.Time, '%Y-%m-%d') = date_format(curdate(), '%Y-%m-%d') then DATE_FORMAT(c.Time,'%H:%i')
else DATE_FORMAT(c.Time,'%Y-%m-%d %H:%i') end as Time FROM m_chat c 
left join m_user u on (u.user_id=c.user_id)
where c.b_id='$bid'
order by c.Time asc");
while($rows = mysql_fetch_array($result))
{
    $return1= "{$rows['firstname']}" ;
     $return2= "{$rows['message']}" ;      
     $return3= "{$rows['Time']}" ; 
     $return4= "{$rows['image']}" ;       
  $my_values[] = $return1;  
   $my_values1[] = $return2;  
    $my_values2[] = $return3;    
 $my_values3[] = $return4; 	
}
		
	
	 echo json_encode(array("firstname"=>$my_values,"message"=>$my_values1,"time"=>$my_values2,"image"=>$my_values3));
		
		
?>